package com.hanlbs.app.controller;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.hanlbs.app.dto.CustomerDTO;
import com.hanlbs.app.dto.PaymentRequest;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Category;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.ShippingInfo;
import com.hanlbs.app.model.Subscription;
import com.hanlbs.app.repo.ShippingInfoRepository;
import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.ProductService;
import com.hanlbs.app.service.SubscriptionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/customerapi")
@Api(tags = "Customer API")
public class CustomerAPI {
	private static final Logger logger = LoggerFactory.getLogger(ProductService.class);

	@Autowired
	ShippingInfoRepository shippingInfoRepo;

	@Autowired
	CustomerService customerService;

	@RequestMapping(value = "/AllCustomers", method = RequestMethod.GET)
	@ApiOperation(value = "customers")

	public ResponseEntity<List<Customer>> customers() {
		logger.info("Edit Controler ..... ");
//		customerService.getCustomer();
		return new ResponseEntity<>(customerService.getCustomer(), HttpStatus.OK);
	}

	@RequestMapping(value = "/editCustomer/{id}", method = RequestMethod.POST)
	@ApiOperation(value = "edit customer")

	public ResponseEntity<?> editcustomer(@PathVariable("id") Long id, @RequestBody CustomerDTO customer) {
		logger.info("Edit Controler ..... ");
		customerService.updateCustomerById(customer, id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/addShippingInfo/{clientId}", method = RequestMethod.POST)
	@ApiOperation(value = "addShippingInfo customer")

	public ResponseEntity<?> addShippingInfo(@PathVariable("clientId") Long id, @RequestBody ShippingInfo shipping) {
		logger.info("add ShippingInfo Category Controler ..... " + id);

		ShippingInfo old=shippingInfoRepo.getbyCustomerId(id);
		
		if (old==null ) {
			Customer cc=customerService.getCustomerById(id);
			
			ShippingInfo result = new ShippingInfo();
			result.setShippingAddress(shipping.getShippingAddress());
			result.setShippingCity(shipping.getShippingCity());
			result.setShippingContury(shipping.getShippingContury());
			result.setShippingState(shipping.getShippingState());
			result.setShippingType(shipping.getShippingType());
			result.setStateId(shipping.getStateId());
			result.setMobile(shipping.getMobile());
			result.setCustomer(cc);
					
					
			return new ResponseEntity<>(shippingInfoRepo.save(result), HttpStatus.OK);
		}else {
			return new ResponseEntity<>("This Customer Had old shipping info you can Edit old one", HttpStatus.INTERNAL_SERVER_ERROR);

		}
		

 
	}

	@RequestMapping(value = "editShippingInfo/{id}", method = RequestMethod.POST)
	@ApiOperation(value = "editShippingInfo")

	public ResponseEntity<?> editShippingInfo(@PathVariable("id") Long id, @RequestBody ShippingInfo shippingInfo) {
		logger.info("Edit ShippingInfo  Controler ..... ");

		ShippingInfo old = shippingInfoRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Shiping info by id " + id + " was not found."));

		old.setShippingAddress(shippingInfo.getShippingAddress());
		old.setShippingCity(shippingInfo.getShippingCity());
		old.setShippingContury(shippingInfo.getShippingContury());
		old.setShippingState(shippingInfo.getShippingState());
		old.setShippingType(shippingInfo.getShippingType());
		old.setStateId(shippingInfo.getStateId());
		old.setMobile(shippingInfo.getMobile());
		return new ResponseEntity<>(shippingInfoRepo.save(old), HttpStatus.OK);
	}

	@RequestMapping(value = "getShippingInfo/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "Get Shipping customer")
	public ResponseEntity<ShippingInfo> getShippingInfo(@PathVariable("id") Long id) {
		logger.info("get ShippingInfo   Controler ..... ");
		ShippingInfo old = shippingInfoRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Shiping info by id " + id + " was not found."));
		return new ResponseEntity<>(old, HttpStatus.OK);
	}

	@RequestMapping(value = "getOrderCustomerDetails/{orderKey}", method = RequestMethod.GET)
	@ApiOperation(value = "Get OrderCustomerDetails")
	public ResponseEntity<?> getOrderCustomerDetails(@PathVariable("orderKey") String orderKey) {
		logger.info("getOrderCustomerDetails");

		return new ResponseEntity<>(customerService.getOrderCustomerDetails(orderKey), HttpStatus.OK);
	}

}
