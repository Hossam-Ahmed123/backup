package com.hanlbs.app.repo;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.shipping.City;
//import com.hanlbs.app.model.shipping.Country;

@Repository
public interface CityRepository extends JpaRepository<City, Long>{

	
	@Query(value = "select * from  city  WHERE name =:name", nativeQuery = true)
	public City findByName(@Param("name") String  name);
	
	
	@Modifying
	@Transactional
	@Query(value = "delete from  city  WHERE id =:id", nativeQuery = true)
	public int remove(@Param("id") Long  id);
	
}
