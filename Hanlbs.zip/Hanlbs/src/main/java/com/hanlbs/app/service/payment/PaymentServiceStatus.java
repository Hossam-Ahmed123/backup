//package com.hanlbs.app.service.payment;
//
//import org.springframework.stereotype.Service;
//
//import com.google.gson.Gson;
//import org.apache.commons.codec.binary.Hex;
//import javax.crypto.Mac;
//import javax.crypto.spec.SecretKeySpec;
//import java.io.BufferedReader;
//import java.io.InputStreamReader;
//import java.io.OutputStream;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.nio.charset.StandardCharsets;
//import java.util.TreeMap;
//
//@Service
//public class PaymentServiceStatus {
//
//	private static final String privateKey = "OPAYPRV16456316098880.014844069459760467";
//
//	private static final String endpoint = "https://sandboxapi.opaycheckout.com";
//
//	private static final String merchantId = "281822022344094";
//
//	public static void main(String[] args) throws Exception {
//		String addr = endpoint + "/api/v1/international/cashier/status";
//		Gson gson = new Gson();
//		TreeMap order = new TreeMap<>();
//		order.put("reference", "34a39c41-4a78-4840-9973-bab98788ec34");
//		order.put("country", "EG");
//
//		String requestBody = gson.toJson(order);
//		System.out.println("--request:");
//		System.out.println(requestBody);
//		String oPaySignature = hmacSHA512(requestBody, privateKey);
//		System.out.println("--signature:");
//		System.out.println(oPaySignature);
//
//		URL url = new URL(addr);
//		HttpURLConnection con = (HttpURLConnection) url.openConnection();
//		con.setRequestMethod("POST");
//		con.setRequestProperty("Content-Type", "application/json; utf-8");
//		con.setRequestProperty("Authorization", "Bearer " + oPaySignature);
//		con.setRequestProperty("MerchantId", merchantId);
//		con.setDoOutput(true);
//		OutputStream os = con.getOutputStream();
//		byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
//		os.write(input, 0, input.length);
//		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
//		StringBuilder response = new StringBuilder();
//		String responseLine = null;
//		while ((responseLine = br.readLine()) != null) {
//			response.append(responseLine.trim());
//		}
//
//		System.out.println("--response:");
//		System.out.println(response.toString());
//		// close your stream and connection
//	}
//
//	public static String hmacSHA512(final String data, final String secureKey) throws Exception {
//		byte[] bytesKey = secureKey.getBytes();
//		final SecretKeySpec secretKey = new SecretKeySpec(bytesKey, "HmacSHA512");
//		Mac mac = Mac.getInstance("HmacSHA512");
//		mac.init(secretKey);
//		final byte[] macData = mac.doFinal(data.getBytes());
//		byte[] hex = new Hex().encode(macData);
//		return new String(hex, StandardCharsets.UTF_8);
//	}
//
//}
