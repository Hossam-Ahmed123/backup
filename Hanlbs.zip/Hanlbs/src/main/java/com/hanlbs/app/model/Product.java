package com.hanlbs.app.model;

import javax.persistence.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "products")
public class Product implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false, length = 128)
	private String name;

	@Column(nullable = false, length = 4000)
	private String description;

	private String color;

	private String colorGroupCode;

	@Column(nullable = false, precision = 10, scale = 2)
	private double price;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@Transient
	private transient String base64Master;
	private String colorSKUCode;

	public String getColorSKUCode() {
		return colorSKUCode;
	}

	public void setColorSKUCode(String colorSKUCode) {
		this.colorSKUCode = colorSKUCode;
	}

	private Date addedOn = new Date();
	@Column(nullable = false, length = 128, unique = true)
	private String sku;
	private double discount;

	@ManyToOne
	@JoinColumn(name = "flashsaleid")
	@JsonIgnoreProperties(value = "flashSaleProducts", allowSetters = true)

	private FlashSale flashSale;

	@ManyToOne
	@JoinColumn(name = "brandid")
	@JsonIgnoreProperties(value = "childrenProducts", allowSetters = true)

	private Brands brand;

	@ManyToOne
	@JoinColumn(name = "categoryid")
	@JsonIgnoreProperties(value = "childrenProducts", allowSetters = true)
	private Category category;
	private String content;
	@OnDelete(action = OnDeleteAction.CASCADE)

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "product")

	private Set<Images> childImages;

	@OnDelete(action = OnDeleteAction.CASCADE)

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "products")

	private Set<ProductReview> childrenReview;
	@OnDelete(action = OnDeleteAction.CASCADE)

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "product")
	@OrderBy("size_order ASC")

	private Set<ProductMeasurementsSize> childrenSize;

//	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "product")
//
//	private Set<ProductMeasurementsSize> childrenSize;

	private String masterImage;

	public Product() {
	}

	public Product(String name, String description, double price) {
		this.name = name;
		this.description = description;
		this.price = price;
	}

	public Product(String name, String description, double price, Date addedOn, String sku, double discount,
			Brands brand, Category category, String content, String parentImage, String color, String colorGroupCode,
			String colorsku) {
		super();

		this.name = name;
		this.description = description;
		this.price = price;
		this.addedOn = addedOn;
		this.sku = sku;
		this.discount = discount;
		this.brand = brand;
		this.category = category;
		this.content = content;
		this.color = color;
		this.colorGroupCode = colorGroupCode;
		this.masterImage = parentImage;
		this.colorSKUCode = colorsku;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Brands getBrand() {
		return brand;
	}

	public void setBrand(Brands brand) {
		this.brand = brand;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return Math.round(price);
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public Set<ProductReview> getChildrenReview() {
		return childrenReview;
	}

	public void setChildrenReview(Set<ProductReview> childrenReview) {
		this.childrenReview = childrenReview;
	}

	public Set<Images> getChildImages() {
		return childImages;
	}

	public void setChildImages(Set<Images> childImages) {
		this.childImages = childImages;
	}

//	@JsonIgnore
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getMasterImage() {
		return masterImage;
	}

	public void setMasterImage(String masterImage) {
		this.masterImage = masterImage;
	}

	public String getBase64Master() {
		return base64Master;
	}

	public void setBase64Master(String base64Master) {
		this.base64Master = base64Master;
	}

	@JsonIgnore
	public FlashSale getFlashSale() {
		return flashSale;
	}

	public void setFlashSale(FlashSale flashSale) {
		this.flashSale = flashSale;
	}

	public Set<ProductMeasurementsSize> getChildrenSize() {
		return childrenSize;
	}

	public void setChildrenSize(Set<ProductMeasurementsSize> childrenSize) {
		this.childrenSize = childrenSize;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getColorGroupCode() {
		return colorGroupCode;
	}

	public void setColorGroupCode(String colorGroupCode) {
		this.colorGroupCode = colorGroupCode;
	}

	@Transient
	public double getPriceAfterDiscount() {
		DecimalFormat df = new DecimalFormat("#.##");

		if (discount > 0) {

			return Double.valueOf(df.format(getPrice() * (1 - (discount / 100))));

		} else {
			return getPrice();
		}

	}

}
