package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.ShippingInfo;

@Repository
public interface ShippingInfoRepository extends JpaRepository<ShippingInfo, Long> {

	@Modifying
	@Transactional
	@Query(value = "insert into shipping_info (shipping_address,shipping_city,shipping_contury,shipping_state,customer_id,shipping_type) values (?1,?2,?3,?4,?5,?6)", nativeQuery = true)
	ShippingInfo addShipping(String add, String city, String contury,  String state, Long cid,String stype);

	
	@Query(value = "select * from  shipping_info where customer_id =:id ", nativeQuery = true)

	ShippingInfo getbyCustomerId(@Param("id")Long id);
	
	
}

