package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hanlbs.app.model.User;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    void deleteById(Long id);

	@Query( value = "SELECT * FROM users u WHERE u.username =:username", nativeQuery = true)

    User findByUsernameandtype (@Param("username") String username);
    User findByUsername (String username);
    Optional<User> findById (Long id);
}
