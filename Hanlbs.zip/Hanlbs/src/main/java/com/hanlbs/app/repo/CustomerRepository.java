package com.hanlbs.app.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
 

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
	void deleteById(Long id);

	Customer findByEmail(String email);

	@Query(value = "SELECT * FROM customer u WHERE u.id =:c_id", nativeQuery = true)
	Customer findById(@Param("c_id") long id);
	
	
	@Query(value = "SELECT * FROM customer", nativeQuery = true)
	List<Customer> all();
	
	
	
	
	@Modifying
	@Transactional
	@Query(value = "insert into  likes (clinetid,productid,sizeid) values (:clinetId,:productId,:sizeid)", nativeQuery = true)
	int addLikes(@Param("clinetId") Long clinetId,@Param("productId") Long productId,@Param("sizeid") Long sizeId) throws BlogNotFoundException;
	 
	
	
	@Modifying
	@Transactional
	@Query(value = "delete from likes where clinetid=:clinetId and productid=:productId and sizeid=:sizeid", nativeQuery = true)
	int removeLikes(@Param("clinetId") Long clinetId,@Param("productId") Long productId,@Param("sizeid") Long sizeId) throws BlogNotFoundException;
	 
	
	
	
}
