package com.hanlbs.app.service;

 
import java.io.IOException;
 
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
 import java.util.ArrayList;
 import java.util.List;
 
 import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.exceptions.BlogNotFoundException;
 import com.hanlbs.app.model.Category;
  import com.hanlbs.app.repo.CategoryRepo;
import com.hanlbs.app.utils.ImageImplementaion;

@Service
@Transactional

public class CategoryService {
	private static final Logger logger = LoggerFactory.getLogger(CategoryService.class);
	@Value("${image.path}")
	private String imagepath;
	@Autowired
	CategoryRepo repo;

	public List<Category> getparentCategory() {
		logger.info("get parent Category  service ..... ");

		List<Category> list = new ArrayList<Category>();

		list = repo.findAllCategoriesbyparent();

		return list;

	}

	public Category getCategoryById(long id) {
		logger.info("get  Category by id service ..... ");

		Category cat = new Category();

		cat = repo.findById(id)
				.orElseThrow(() -> new   BlogNotFoundException("category by id " + id + " was not found."));

		return cat;

	}

	public int getMasterCategory(long id) {

		int parntCat = repo.findAllparentcategorybysub(id);

		return parntCat;
	}

	public void addCategory(Category category) throws BlogNotFoundException{
		logger.info("add new Category  service ..... ");

		repo.insertSubcate(category.getName(), category.getParentCategoryId(),
				new ImageImplementaion().encodeBase64BinarytoFile(category.getBase64cover(), imagepath));
	}

	private boolean deleteCoverVisicalImages(Long id) throws BlogNotFoundException{
		Category oldCategory = getCategoryById(id);
		String mImage = oldCategory.getCoverPhoto();
		mImage.replaceAll("-", "/");
		Path masterImage = Paths.get(imagepath + mImage);
		boolean result = false;

		try {
			result = Files.deleteIfExists(masterImage);

		} catch (IOException e) {
			logger.error("Error  ", e);
		}

		return result;
	}

	public Category updateCategoryCover(Long id, Category category)throws BlogNotFoundException {

		logger.info("update  Product  service ..... " + id);

		if (deleteCoverVisicalImages(id) == true) {
			logger.info("update  Product  service ..... " + id);

		}

		Category oldcCategory = getCategoryById(id);

		if (category.getBase64cover() == null || category.getBase64cover().isEmpty()
				|| category.getBase64cover().equals("")) {

		} else {
			oldcCategory.setCoverPhoto(
					new ImageImplementaion().encodeBase64BinarytoFile(category.getBase64cover(), imagepath));

		}
		return repo.save(oldcCategory);
	}

	public Category updateCategory(Long id, Category category)throws BlogNotFoundException {

		logger.info("update  category  service ..... " + id);

		if (deleteCoverVisicalImages(id) == true) {
			logger.info("update  category  service ..... " + id);

		}

		Category oldcCategory = getCategoryById(id);

		oldcCategory.setName(category.getName());
		if (category.getBase64cover() == null || category.getBase64cover().isEmpty()
				|| category.getBase64cover().equals("")) {

		} else {
			oldcCategory.setCoverPhoto(
					new ImageImplementaion().encodeBase64BinarytoFile(category.getBase64cover(), imagepath));

		}

		oldcCategory.setsKUCode(category.getsKUCode());

		return repo.save(oldcCategory);

	}

	public void deleteSubCat(long id) throws BlogNotFoundException{

		repo.deleteSubcate(id);

	}

}
