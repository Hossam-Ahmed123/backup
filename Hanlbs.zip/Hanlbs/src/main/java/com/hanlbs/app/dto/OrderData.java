package com.hanlbs.app.dto;

import java.util.List;

import com.hanlbs.app.model.Orders;

import lombok.Data;


@Data
public class OrderData {
	
	
	private List<Orders> orders;
	
	private int totalCount;

	public List<Orders> getOrders() {
		return orders;
	}

	public void setOrders(List<Orders> orders) {
		this.orders = orders;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	
	
	

}
