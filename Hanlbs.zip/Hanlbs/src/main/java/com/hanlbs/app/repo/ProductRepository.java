package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.Product;

import java.util.List;
import java.util.Optional;

@Repository

public interface ProductRepository extends JpaRepository<Product, Long> {
	@Modifying
	@Transactional

	@Query(value = "DELETE FROM products WHERE id =:c_id", nativeQuery = true)
	void deleteById(@Param("c_id") long id);

	@Query(value = "SELECT * FROM products u WHERE u.id =:c_id", nativeQuery = true)

	Product findById(@Param("c_id") long id);

	@Query(value = "SELECT * FROM products u WHERE u.categoryid =:c_id", nativeQuery = true)
	List<Product> findByCategory(@Param("c_id") long id);

	@Query(value = "SELECT * FROM products u WHERE u.brandid =:brandid", nativeQuery = true)
	List<Product> findBybrand(@Param("brandid") long id);

	@Query(value = "SELECT * FROM products u WHERE u.sku =:sku", nativeQuery = true)
	Product findBySKU(@Param("sku") String sku);

	@Query(value = "SELECT * FROM products u WHERE u.name LIKE %:name%", nativeQuery = true)
	List<Product>  findByName(@Param("name") String name);
	
	@Query(value = "SELECT * FROM products u WHERE u.name =:name", nativeQuery = true)
	Product  SearchByNAme(@Param("name") String name);
	

	@Query(value = "SELECT * FROM products u WHERE u.price BETWEEN :p1 AND :p2", nativeQuery = true)
	List<Product>  findByPrice(@Param("p1") double p1,@Param("p2") double p2);

	@Modifying
	@Transactional
	@Query(value = "update  products set flashsaleid = null , discount = 0 WHERE flashsaleid =:c_id", nativeQuery = true)
	void updateflashsale(@Param("c_id") long id);

	@Modifying
	@Transactional
	@Query(value = "update  products set flashsaleid = null , discount = 0 WHERE id =:c_id", nativeQuery = true)
	void updateflashsalebyProdctid(@Param("c_id") long id);

//	@Query(value = "SELECT * FROM products u inner join flash_sale f on u.id =f.flash_sale_products_id and CAST(f.end AS datetime) > SYSDATE() AND CAST(f.start AS datetime) < SYSDATE()  ", nativeQuery = true)
//	List<Product> findByFlashSale();
//
//	@Query(value = "SELECT * FROM products u inner join flash_sale f on u.id =f.flash_sale_products_id and CAST(f.end AS datetime) < SYSDATE() AND u.discount <> 0 and u.in_flash_sale <> 0 ", nativeQuery = true)
//	List<Product> findByEndFlashSale();

	@Query(value = "SELECT * FROM products u inner join category cat on  u.categoryid = cat.category_id  and cat.parencatid =:c_id", nativeQuery = true)
	List<Product> findByMasterCategory(@Param("c_id") long id);

	@Query(value = "SELECT * FROM products u inner join product_review r on  u.id = r.productid and r.rating > 3", nativeQuery = true)
	List<Product> findBywithInReview();

	@Query(value = "SELECT * FROM products u inner join product_review r  inner join category cat on  u.id = r.productid and r.rating > 3 and u.categoryid = cat.category_id  and cat.parencatid =:c_id", nativeQuery = true)

	List<Product> getTopRatedbyMasterCategory(@Param("c_id") long id);

	@Modifying
	@Transactional
	@Query(value = "update  products set flashsaleid = :c_id  WHERE id =:pid and discount<>0", nativeQuery = true)
	void addFlash(@Param("pid") long prod, @Param("c_id") long flashId);

	@Query(value = "SELECT * FROM products u WHERE u.flashsaleid is null ", nativeQuery = true)

	List<Product> withnoFlash();

	
	
	@Query(value = "SELECT * FROM products u WHERE u.color_group_code =:colorgroupcode", nativeQuery = true)
 	List<Product> findBycolorgroupcode(String colorgroupcode);

//	@Query(value = "SELECT * FROM products u inner join  category cat on u.categoryid = cat.category_id and cat.parencatid =:c_id and flashsaleid <> 0", nativeQuery = true)
//
//	List<Product> getFlashSaleByMasterCategory(@Param("c_id") long id);

}
