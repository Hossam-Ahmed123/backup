package com.hanlbs.app.dto;

public class ShippingDTO {
	
	private String country;
	private String countryShortName;
	private String state;
	private double shippingFees;
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryShortName() {
		return countryShortName;
	}
	public void setCountryShortName(String countryShortName) {
		this.countryShortName = countryShortName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getShippingFees() {
		return shippingFees;
	}
	public void setShippingFees(double shippingFees) {
		this.shippingFees = shippingFees;
	}
	
	
	
	

}
