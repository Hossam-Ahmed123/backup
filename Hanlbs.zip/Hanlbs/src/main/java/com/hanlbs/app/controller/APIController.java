package com.hanlbs.app.controller;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import com.hanlbs.app.config.JwtUtil;
import com.hanlbs.app.dto.WishListDto;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.FlashSale;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductReview;
import com.hanlbs.app.model.Subscription;
import com.hanlbs.app.model.User;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.cart.CartItemPK;
import com.hanlbs.app.service.CartItemService;
import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.FlashSaleService;
import com.hanlbs.app.service.JwtUserDetailsService;
import com.hanlbs.app.service.ProductService;
import com.hanlbs.app.service.SubscriptionService;
import com.hanlbs.app.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.transaction.Transactional;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/api")
@Api(tags = "Product API")

public class APIController {
	private static final Logger logger = LoggerFactory.getLogger(APIController.class);
	@Value("${image.path}")
	private String imagepath;
	@Autowired
	SubscriptionService subscriptionService;
	private final ProductService productService;
	@Autowired

	private FlashSaleService flashSaleService;
	@Autowired

	private CustomerService customerService;

	public APIController(ProductService productService) {

		this.productService = productService;
	}
//
//	@RequestMapping(value = "/addWishList", method = RequestMethod.POST)
//	@ApiOperation(value = "addWishList")
//
//	public ResponseEntity<?> addWishList(@RequestBody WishListDto wishList) throws BlogNotFoundException {
//		logger.info("Add WishList Controler ..... ");
//		try {
//
//			int result = customerService.addWishList(wishList);
//			if (result > 0) {
//				return new ResponseEntity<>(HttpStatus.OK);
//
//			} else {
//				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//
//			}
//		} catch (Exception e) {
//			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//		}
//	}
//	@RequestMapping(value = "/removeWishList/{customerId}/{ProductID}/{sizeID}", method = RequestMethod.DELETE)
//	@ApiOperation(value = "removeWishList")
//
//	public ResponseEntity<?> removeWishList(@PathVariable("customerId") Long customerId
//			,@PathVariable("ProductID") Long ProductID,@PathVariable("sizeID") Long sizeID) throws BlogNotFoundException {
//		logger.info("Add WishList Controler ..... ");
//		try {
//
//			int result = customerService.removeWishList(customerId, ProductID,sizeID);
//			if (result > 0) {
//				return new ResponseEntity<>(HttpStatus.OK);
//
//			} else {
//				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//
//			}
//		} catch (Exception e) {
//			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//		}
//	}
//
	@GetMapping("/getproductById/{id}")
	public ResponseEntity<Product> getProduct(@PathVariable("id") Long id) throws BlogNotFoundException{
		logger.info("getProduct  by id  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByID(id), HttpStatus.OK);
	}

	@GetMapping("/getproductByName/{name}")
	public ResponseEntity<	Product > getProductByName(@PathVariable("name") String name) throws BlogNotFoundException{
		logger.info("getProduct  by Name  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByName(name), HttpStatus.OK);
	}
	

	@GetMapping("/HomeSearch/{name}")
	public ResponseEntity<	List<Product> > homeSearch(@PathVariable("name") String name) throws BlogNotFoundException{
		logger.info("getProduct  by Name  Controler ..... ");

		return new ResponseEntity<>(productService.homeSearch(name), HttpStatus.OK);
	}
	@GetMapping("/getproductByPriceRange/{from}/{to}")
	public ResponseEntity<	List<Product> > getProductByPriceRange(@PathVariable("from") double p1,@PathVariable("to") double p2) throws BlogNotFoundException{
		logger.info("getProduct  by Name  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByPriceRange(p1, p2), HttpStatus.OK);
	}

	@GetMapping("/getproductByNamecolorGroub/{name}")
	@ApiOperation(value = "get Products By color group code")
	public ResponseEntity<List<Product>> getProductBycolorgroupcode(@PathVariable("name") String name) throws BlogNotFoundException{
		logger.info("getProduct  by color group code  Controler ..... ");

		return new ResponseEntity<>(productService.getProductcolorgroupcode(name), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/getproductBySku/{sku}")
	public ResponseEntity<Product> getProductBySKU(@PathVariable("sku") String sku) throws BlogNotFoundException{
		logger.info("getProduct  by SKU  Controler ..... ");

		return new ResponseEntity<>(productService.getProductBySKU(sku), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/products")
	public ResponseEntity<List<Product>> getProducts() throws BlogNotFoundException{
		logger.info("getProducts  Controler ..... ");

		return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
	}

	@GetMapping("/page/products")
	public ResponseEntity<?> getProductsPage(Pageable pageable) throws BlogNotFoundException{
		logger.info("getProducts  Controler ..... ");

		return new ResponseEntity<>(productService.getAllProducts(pageable), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/TopRated")
	public ResponseEntity<List<Product>> getTopRatedProducts()throws BlogNotFoundException {
		logger.info("get Top Rated Products  Controler ..... ");

		return new ResponseEntity<>(productService.getAllProductsWithHigeRate(), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/productsByBrand/{brandid}")
	public ResponseEntity<List<Product>> getProductByBrand(@PathVariable("brandid") Long id)throws BlogNotFoundException {

		logger.info("getProduct  by Brand id  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByBrand(id), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/productsbyCategory/{catid}")
	public ResponseEntity<List<Product>> getProductByCategory(@PathVariable("catid") Long id) throws BlogNotFoundException{

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByCategory(id), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/productsbyMasterCategory/{mastrId}")
	public ResponseEntity<List<Product>> getProductByMasterCategory(@PathVariable("mastrId") Long id)throws BlogNotFoundException {

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getProductByMasterCategory(id), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/TopRatedProductsbyMasterCategory/{mastrId}")
	public ResponseEntity<List<Product>> getTopRatedProductByMasterCategory(@PathVariable("mastrId") Long id) throws BlogNotFoundException{

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getTopRatedProductByMasterCategory(id), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

//
	@GetMapping("/FlashSaleProductsbyMasterCategory/{mastrId}")
	public ResponseEntity<FlashSale> getFlashSaleProductByMasterCategory(@PathVariable("mastrId") Long id)throws BlogNotFoundException {

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getFlashSaleProductByMasterCategory(id), HttpStatus.OK);
	}
//	

	@GetMapping("/images/{filename}")
	public ResponseEntity<byte[]> getImage(@PathVariable("filename") String filename) throws BlogNotFoundException{
		byte[] image = new byte[0];
		logger.info("getImage by image name Controler ..... " + filename);

		try {
			if (filename.contains("-")) {
				filename = filename.replaceAll("-", "/");
			}

			image = FileUtils.readFileToByteArray(new File(imagepath + filename));
		} catch (IOException e) {
			logger.error("Error", e);
		}
		return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(image);
	}
//

	@GetMapping("/FlashSaleProductsByFlashSaleID/{mastrId}")
	public ResponseEntity<FlashSale> getFlashSaleProductsByFlashSaleID(@PathVariable("mastrId") Long id) throws BlogNotFoundException{
		logger.info("FlashSale  Controler ..... ");

		return new ResponseEntity<>(flashSaleService.getFlashSaleByID(id), HttpStatus.OK);
	}

	@CrossOrigin(origins = { "http://137.184.146.80", "http://137.184.146.80:8080", "http://localhost:4200" })

	@GetMapping("/FlashSaleProductsByBrandID/{mastrId}")
	public ResponseEntity<FlashSale> getFlashSaleProductsByBrand(@PathVariable("mastrId") Long id) throws BlogNotFoundException{
		logger.info("FlashSale  brand Controler ..... ");

		return new ResponseEntity<>(productService.getFlashSaleProductByBrand(id), HttpStatus.OK);
	}

	@GetMapping("/AllFlashSale")
	public ResponseEntity<List<FlashSale>> getAllFlashSale() throws BlogNotFoundException{

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(flashSaleService.getAllflashSale(), HttpStatus.OK);
	}

	@GetMapping("/productWithNoFlashSale")
	public ResponseEntity<List<Product>> getproductWithNoFlashSale() throws BlogNotFoundException{

		logger.info("getProduct  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getProductswithNoflashSale(), HttpStatus.OK);
	}

	@GetMapping("/mostRecomended/{productID}/{catID}")
	public ResponseEntity<List<Product>> getmostRecomended(@PathVariable("productID") Long pId,
			@PathVariable("catID") Long catId) throws BlogNotFoundException{

		logger.info("most Recomended  by Category id  Controler ..... ");

		return new ResponseEntity<>(productService.getmostRecomended(pId, catId), HttpStatus.OK);
	}

	@RequestMapping(value = "/addReviw", method = RequestMethod.POST)
	@ApiOperation(value = "Add Reviw")

	public ResponseEntity<ProductReview> addReviw(@RequestBody ProductReview reviwe) {
		logger.info("Add Reviw Controler ..... ");
		productService.addProductReview(reviwe);
		return new ResponseEntity<>(productService.addProductReview(reviwe),HttpStatus.OK);
	}

	@RequestMapping(value = "/addsubscription", method = RequestMethod.POST)
	@ApiOperation(value = " customer Subscription")

	public ResponseEntity<?> addsubscription(@RequestBody Subscription addsubscription) {

		Subscription sub = subscriptionService.addSub(addsubscription);

		return new ResponseEntity<>(sub, HttpStatus.OK);
	}

	@RequestMapping(value = "/allSubscriptions", method = RequestMethod.GET)
	@ApiOperation(value = "allSubscriptions")
	public ResponseEntity<List<Subscription>> getShippingInfo()throws BlogNotFoundException {
		logger.info("get allSubscriptions   Controler ..... ");

		return new ResponseEntity<>(subscriptionService.subscriptions(), HttpStatus.OK);
	}

}
