package com.hanlbs.app.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hanlbs.app.dto.ShippingDTO;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.FlashSale;
import com.hanlbs.app.model.PromoCode;
import com.hanlbs.app.model.ShippingFees;
import com.hanlbs.app.model.shipping.City;
import com.hanlbs.app.model.shipping.Country;
import com.hanlbs.app.service.ShippingFeesService;
import com.hanlbs.app.service.ShippingService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/ShippingFeesAPI")
@Api(tags = "ShippingFees API")
public class ShippingFeesController {
	private static final Logger logger = LoggerFactory.getLogger(ShippingFeesController.class);

	@Autowired
	ShippingFeesService serv;

	@Autowired
	ShippingService shippingService;

//	@RequestMapping(value = "/addShippingFees", method = RequestMethod.POST)
//	@ApiOperation(value = "addShippingFees")
//	public ResponseEntity<?> addFees(@RequestBody ShippingFees shpp) throws BlogNotFoundException {
//
//		logger.info("Add ShippingFeesController Controler ..... ");
//
//		return ResponseEntity.ok(serv.addShippingFees(shpp));
//
//	}
//
//	@RequestMapping(value = "/editShippingFees/{id}", method = RequestMethod.POST)
//	@ApiOperation(value = "addShippingFees")
//	public ResponseEntity<?> editFees(@RequestBody ShippingFees shpp, @PathVariable("id") long id)
//			throws BlogNotFoundException {
//
//		logger.info("Edit ShippingFeesController Controler ..... ");
//
//		return ResponseEntity.ok(serv.editShippingFees(shpp, id));
//
//	}
//
//	@RequestMapping(value = "/AllFees", method = RequestMethod.GET)
//	@ApiOperation(value = "AllFees")
//	public ResponseEntity<?> editFees() throws BlogNotFoundException {
//
//		logger.info(" AllFees Controler ..... ");
//
//		return ResponseEntity.ok(serv.allShippingFees());
//
//	}
//
//	@RequestMapping(value = "getShippingValue/{id}", method = RequestMethod.GET)
//	@ApiOperation(value = "getShippingValue")
//	public ResponseEntity<ShippingFees> getShippingValue(@PathVariable("id") Long id) {
//		logger.info("get ShippingInfo value   Controler ..... ");
//		ShippingFees old = serv.ShippingFees(id);
//
//		return new ResponseEntity<>(old, HttpStatus.OK);
//	}
	@RequestMapping(value = "/stateByID/{stateid}", method = RequestMethod.GET)
	@ApiOperation(value = "stateByID")
	public ResponseEntity<City> state(@PathVariable("stateid") Long id) throws BlogNotFoundException {

		return new ResponseEntity<>(shippingService.cityByID(id), HttpStatus.OK);
	}
	@RequestMapping(value = "/Countries", method = RequestMethod.GET)
	@ApiOperation(value = "Countries")
	public ResponseEntity<List<Country>> shippingData() throws BlogNotFoundException {

		return new ResponseEntity<>(shippingService.allCountries(), HttpStatus.OK);
	}

	@RequestMapping(value = "/addShippingData", method = RequestMethod.POST)
	@ApiOperation(value = "addShippingData")
	public ResponseEntity<City> addFees(@RequestBody ShippingDTO shpp) throws BlogNotFoundException {

		Country country = shippingService.addCountry(shpp.getCountry(),shpp.getCountryShortName());
		City c = shippingService.addCity(shpp.getState(), shpp.getShippingFees(), country);

		return new ResponseEntity<>(c, HttpStatus.OK);

	}

	@PutMapping("/updateShippingFees/{id}/{shippingFees}/{active}")
	@ApiOperation(value = "active true send  1 || active false send 0 ")
	public ResponseEntity<City> updateCity(@PathVariable("id") Long id, @PathVariable("shippingFees") double fees, @PathVariable("active") int active)
			throws BlogNotFoundException {

		return new ResponseEntity<>(shippingService.editCity(id, fees,active), HttpStatus.OK);
	}

	
	@DeleteMapping("/deleteCity/{id}")
	@ApiOperation(value = "active true send  1 || active false send 0 ")
	public ResponseEntity<?> deleteCity(@PathVariable("id") Long id)
			throws BlogNotFoundException {

		return new ResponseEntity<>(shippingService.removeCity(id), HttpStatus.OK);
	}
	
	@PutMapping("/activateCountry/{countryid}/{active}")
	@ApiOperation(value = "active true send  1 || active false send 0 ")
	public ResponseEntity<Country> activeCountry(@PathVariable("countryid") Long id,  @PathVariable("active") int active)
			throws BlogNotFoundException {

		return new ResponseEntity<>(shippingService.activateCountry(id,active), HttpStatus.OK);
	}
	
}
