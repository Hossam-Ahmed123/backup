package com.hanlbs.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.shipping.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, Long>{

	
	@Query(value = "select * from  country  WHERE country =:name", nativeQuery = true)
	public Country findByName(@Param("name") String  name);
	
}
