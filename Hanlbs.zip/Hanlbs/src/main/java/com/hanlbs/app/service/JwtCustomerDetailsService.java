package com.hanlbs.app.service;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.User;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.repo.UserRepository;

@Service
public class JwtCustomerDetailsService implements UserDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(JwtUserDetailsService.class);

	@Autowired
	private CustomerRepository repo;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Customer user = repo.findByEmail(email);
		logger.info("load Customer By Username Service ..... " + email);

		if (user == null) {
			throw new UsernameNotFoundException("Customer not found with the email of: " + email);
		}

		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				new ArrayList<>());
	}

	public Customer save(Customer customer) {
		logger.info("save Customer By Customer object Service ..... ");

		Customer newUser = new Customer( bcryptEncoder.encode(customer.getPassword()),
				customer.getEmail(), customer.getName(), customer.getPhone());

		return repo.save(newUser);
	}

}
