package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.wishlist.WishList;
import com.hanlbs.app.model.wishlist.WishListPK;

@Repository
public interface WishListRepository  extends JpaRepository<WishList, WishListPK>{

}
