package com.hanlbs.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hanlbs.app.model.Category;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.service.CategoryService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/category")
public class CategoryController {
	private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);

	@Autowired
	private CategoryService service;

	

	@GetMapping("/allcate")
	@ApiOperation(value = "List All Categories")

	public ResponseEntity<List<Category>> getCategories() {

		if (logger.isDebugEnabled()) {
			logger.debug("Hello from Log4j 2 - num : {}");
		}

		// java 8 lambda, no need to check log level
		logger.debug("Hello from Log4j 2 - num : {}");

		return new ResponseEntity<>(service.getparentCategory(), HttpStatus.OK);
	}

	

	@GetMapping("/categoryById/{id}")
	@ApiOperation(value = "get Category By id")

	public ResponseEntity<Category> getCategoryByID(@PathVariable("id") Long id) {
		logger.info("get Category  by id  Controler ..... ");

		return new ResponseEntity<>(service.getCategoryById(id), HttpStatus.OK);
	}

	

	@GetMapping("/getMasterCategoryBySubID/{id}")
	@ApiOperation(value = "get Master Category By sub  id")

	public ResponseEntity<?> getMasterCategoryBySubID(@PathVariable("id") Long id) {
		logger.info("get Category  by id  Controler ..... ");
		int subcatid = service.getMasterCategory(id);

		Map<String, Integer> catresp = new HashMap<>();

		catresp.put("MasterCategoryId", subcatid);
		return ResponseEntity.ok(catresp);

	}

}
