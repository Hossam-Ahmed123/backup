package com.hanlbs.app.model.orderdetails;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "order_details")
public class OrderDetails {

	@EmbeddedId
	@JsonIgnore
	private OrderDetailsPK pk;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date addedOn = new Date();
	@Column(nullable = false)
	private int quantity = 1;
	private String color;
	private String size;

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	private String sku;
	private double price;
	private double discount;

	private boolean isOrdered;
	

	private int active;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date createdAt = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date updatedAt = new Date();
	private String content;

	public OrderDetails() {
	}

	public OrderDetails(Customer customer, Product product,ProductMeasurementsSize pSize, int quantity, String color, String size, double price,
			String sKU) {

		pk = new OrderDetailsPK();
		pk.setCustomer(customer);
		pk.setProduct(product);
		pk.setProductSize(pSize);
		
		this.quantity = quantity;
		this.color = color;
		this.size = size;
		this.price = price;
		this.sku = sKU;
	}

	@Transient
	public Product getProduct() {
		return pk.getProduct();
	}

	@Transient
	public double getTotalPrice() {
		return Math.round(quantity * getProduct().getPriceAfterDiscount());
	}

	public OrderDetailsPK getPk() {
		return pk;
	}

	public void setPk(OrderDetailsPK pk) {
		this.pk = pk;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null || getClass() != o.getClass())
			return false;

		OrderDetails that = (OrderDetails) o;
		return Objects.equals(pk.getCustomer().getId(), that.pk.getCustomer().getId())
				&& Objects.equals(getProduct().getId(), that.getProduct().getId());
	}

	
	public boolean isOrdered() {
		return isOrdered;
	}

	public void setOrdered(boolean isOrdered) {
		this.isOrdered = isOrdered;
	}

 

}
