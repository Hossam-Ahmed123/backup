package com.hanlbs.app.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import io.swagger.annotations.SwaggerDefinition;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)

@SwaggerDefinition(consumes = { "application/json", "application/xml" }, produces = { "application/json",
		"application/xml" }, schemes = { SwaggerDefinition.Scheme.HTTP, SwaggerDefinition.Scheme.HTTPS })
public class WebSecurityConfig extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {
	private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);

	@Autowired
	private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;

	@Autowired
	private JwtRequestFilter jwtRequestFilter;

	@Autowired
	private UserDetailsService jwtUserDetailsService;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) {
		try {
			auth.userDetailsService(jwtUserDetailsService).passwordEncoder(passwordEncoder());
		} catch (Exception e) {
			logger.error("Exception ", e);
		}
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//    	  http.cors().and().csrf().disable()
//          .authorizeRequests().antMatchers("/login", "/register", "/api/**/*","/swagger-ui/**/*","/v3/**/*",
//                  "/configuration/ui",
//                  "/swagger-resources/**",
//                  "/configuration/security",
//                  "/swagger-ui/","/myapp/login", "/myapp/register",
//                  "/webjars/**","/category/**/*").permitAll() 
//                .anyRequest().authenticated().and().exceptionHandling()
//                .authenticationEntryPoint(jwtAuthenticationEntryPoint).and().sessionManagement()
//                .sessionCreationPolicy(SessionCreationPolicy.STATELESS);
//
//        http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);
//    }

	 
	
	@Override
	protected void configure(HttpSecurity http) {
	
		try {
			http.cors().and().csrf().disable().authorizeRequests()
					.antMatchers("/configuration/ui", "/swagger-resources/**", "/configuration/security",
							"/swagger-ui/", "/webjars/**", "/category/**/*", "/CustomerLogin", "/customerRegister",
							"/controllogin", "/userRegister", "/api/**/*", "/brands/**/*", "/swagger-ui/**/*")
					.permitAll().anyRequest().authenticated().and().exceptionHandling()
					.authenticationEntryPoint(jwtAuthenticationEntryPoint).and().sessionManagement()
					.sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		} catch (Exception e) {
			logger.error("Error", e);
		}

		http.addFilterBefore(jwtRequestFilter, UsernamePasswordAuthenticationFilter.class);
	}

	@Override
	public void configure(WebSecurity web) {
		web.ignoring().antMatchers(HttpMethod.GET).antMatchers("/configuration/ui", "/swagger-resources/**",
				"/configuration/security", "/brands/**/*", "/swagger-ui/", "/login", "/CustomerLogin",
				"/customerRegister", "/controllogin", "/userRegister", "/webjars/**", "/category/**/*");
	}

//	@Bean
//    public CorsFilter corsFilter() {
//        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//        CorsConfiguration config = new CorsConfiguration();
//        config.setAllowCredentials(true);
//        config.addAllowedOrigin("*");
//        config.addAllowedHeader("*");
//        config.addAllowedMethod("OPTIONS");
//        config.addAllowedMethod("GET");
//        config.addAllowedMethod("POST");
//        config.addAllowedMethod("PUT");
//        config.addAllowedMethod("DELETE");
//        source.registerCorsConfiguration("/**", config);
//        return new CorsFilter(source);
//    }
//	
//	
	@Bean
	public WebMvcConfigurer corsConfigurer() {

		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**")
						.allowedOrigins("http://localhost:4200",
								"http://localhost:4200/","http://137.184.146.80",
								"https://www.hnlbs.co/",
								"https://www.hnlbs.co",
								"https://hnlbs.co/",
								"https://hnlbs.co",
								"http://localhost:4200",
								"http://137.184.146.80/",
								"137.184.146.80");	
					 
			}
		};
	}
	

}
