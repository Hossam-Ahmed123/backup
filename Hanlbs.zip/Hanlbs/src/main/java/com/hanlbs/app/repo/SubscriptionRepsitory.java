package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hanlbs.app.model.ShippingInfo;
import com.hanlbs.app.model.Subscription;

public interface SubscriptionRepsitory extends JpaRepository<Subscription, Long> {

}
