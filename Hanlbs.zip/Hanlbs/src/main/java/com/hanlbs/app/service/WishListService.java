package com.hanlbs.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.config.JwtAuthenticationEntryPoint;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.exceptions.CartItemAlreadyExistsException;
import com.hanlbs.app.exceptions.CartItemDoesNotExistsException;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.wishlist.WishList;
import com.hanlbs.app.repo.CartItemRepository;
import com.hanlbs.app.repo.WishListRepository;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class WishListService {
	private static final Logger logger = LoggerFactory.getLogger(WishListService.class);

	@Autowired
	private WishListRepository repo;

	public WishListService(WishListRepository repo) {
		this.repo = repo;
	}

	public List< WishList> getWishList() {
		return repo.findAll();
	}

	public  WishList getCartItem(Long customerId, Long productId) {
		logger.info("get WishList by  userId and productId service ..... " + customerId);

		for (WishList item : getWishList()) {
			if (item.getPk().getCustomer().getId() == customerId && item.getPk().getProduct().getId() == productId) {
				return item;
			}
		}

		throw new CartItemDoesNotExistsException(
				"WishList w/ user id " + customerId + " and product id " + productId + " does not exist.");
	}

//	public CartItem getCartItemByID(Long cartID) {
//		logger.info("get CartItem by  userId and productId service ..... " + cartID);
//
//		return repo.findById(cartID)
//				.orElseThrow(() -> new ProductNotFoundException("Product by id " + cartID + " was not found."));
//
//	}

	public  WishList addWishList(WishList wishList) throws BlogNotFoundException {
		logger.info("add WishList service ..... ");

		for (WishList item : getWishList()) {
			if (item.getPk().getCustomer().equals(wishList.getPk().getCustomer())
					&& item.getPk().getProduct().equals(wishList.getPk().getProduct())
					&& item.getPk().getSize().equals(wishList.getPk().getSize())) {
				throw new CartItemAlreadyExistsException(
						"WishList w/ user id " + wishList.getPk().getCustomer().getId() + " and product id "
								+ wishList.getProduct().getId() + " already exists.");
			}
		}

		return this.repo.save(wishList);
	}

	public  WishList updateWishList(WishList wishList) throws BlogNotFoundException {
		logger.info("update WishList  service ..... ");

		for (WishList item : getWishList()) {
			if (item.equals(wishList)) {
 				return repo.save(item);
			}
		}

		throw new CartItemDoesNotExistsException("WishList w/ user id " + wishList.getPk().getCustomer().getId()
				+ " and product id " + wishList.getProduct().getId() + " does not exist.");
	}

	 

	public void deleteWishList(Long userId, Long productId, Long sizeID) throws BlogNotFoundException {
		logger.info("Delete WishList  service ..... ");

		for (WishList item : getWishList()) {
			if (item.getPk().getCustomer().getId() == userId && item.getPk().getProduct().getId() == productId
					&& item.getPk().getSize().getId() == sizeID) {
				repo.delete(item);
				return;
			}
		}

		throw new CartItemDoesNotExistsException(
				"WishList w/ user id " + userId + " and product id " + productId + " does not exist.");
	}
}
