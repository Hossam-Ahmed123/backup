package com.hanlbs.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.cart.CartItemPK;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, CartItemPK> {

	@Modifying
	@Transactional
	@Query(value = "update cart_item set is_ordered = 1 , order_key = :key WHERE customer_id =:c_id", nativeQuery = true)
	public int updateCartOrder(@Param("key") String key, @Param("c_id") long id);

	public List<CartItem> findAllByOrderKey(String orderkey);
	
	@Query(value = "select * from  cart_item  WHERE customer_id =:c_id", nativeQuery = true)
	public List<CartItem> findAllBycustomerId(@Param("c_id") long customer);

	
	@Modifying
	@Transactional
	@Query(value = "Delete from cart_item   WHERE customer_id =:c_id", nativeQuery = true)
	public int deleteCartOrder( @Param("c_id") long id);
	
	
}
