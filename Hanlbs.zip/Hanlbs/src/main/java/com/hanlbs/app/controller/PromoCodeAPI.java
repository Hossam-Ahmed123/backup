package com.hanlbs.app.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hanlbs.app.dto.CustomerDTO;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.PromoCode;
import com.hanlbs.app.service.PromoCodeService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/PromoCodeAPI")
@Api(tags = "PromoCode API")
public class PromoCodeAPI {

	private static final Logger logger = LoggerFactory.getLogger(PromoCodeAPI.class);
	@Autowired
	PromoCodeService promoService;

	@RequestMapping(value = "/getAllPromoCodes", method = RequestMethod.GET)
	@ApiOperation(value = "All PromoCodes")
	public ResponseEntity<List<PromoCode>> AllPromo() {

		logger.info("Get All PromoCode Controler ..... ");

		return ResponseEntity.ok(promoService.allPromocodes());

	}

	@RequestMapping(value = "/PromoValueForCustomer/{pmName}/{customerId}", method = RequestMethod.GET)
	@ApiOperation(value = "get PromoCode by id")
	public ResponseEntity<?> PromoByNameAndCustomerID(@PathVariable("customerId") Long id,
			@PathVariable("pmName") String pmName) {

		logger.info("get PromoCode by CustomerId Controler ..... ");

		return ResponseEntity.ok(promoService.getPromoByIdAndPromoNAme(id, pmName));

	}

	@RequestMapping(value = "/getPromoCodeById/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "get PromoCode by id")
	public ResponseEntity<PromoCode> PromoByID(@PathVariable("id") Long id) {

		logger.info("get PromoCode by id Controler ..... ");

		return ResponseEntity.ok(promoService.getPromoById(id));

	}

	@RequestMapping(value = "/addPromo", method = RequestMethod.POST)
	@ApiOperation(value = "addPromo")
	public ResponseEntity<?> addPromo(@RequestBody PromoCode promoCode)throws BlogNotFoundException {

		logger.info("Add PromoCode Controler ..... ");

		return ResponseEntity.ok(promoService.addPromo(promoCode));

	}

	@RequestMapping(value = "/EditPromo/{id}", method = RequestMethod.POST)
	@ApiOperation(value = "Edit Promo")
	public ResponseEntity<?> addPromo(@PathVariable("id") Long id, @RequestBody PromoCode promoCode) throws BlogNotFoundException{

		logger.info("Edit PromoCode Controler ..... ");

		return ResponseEntity.ok(promoService.updatePromro(promoCode, id));

	}

	@RequestMapping(value = "/DeletePromo/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete Promo")
	public ResponseEntity<?> deletePromo(@PathVariable("id") Long id)throws BlogNotFoundException {

		logger.info("Delete PromoCode Controler ..... ");

		promoService.deletePromocode(id);

		return new ResponseEntity<>(HttpStatus.OK);

	}

	@Transactional

	@RequestMapping(value = "linkPromoCode/{promoId}/{clientId}", method = RequestMethod.GET)
	@ApiOperation(value = "linkPromoCode customer")

	public ResponseEntity<?> linkPromoCode(@PathVariable("promoId") Long promoId,
			@PathVariable("clientId") Long clientId)throws BlogNotFoundException {

		String r=promoService.linkPromocode(promoId,clientId);

		return new ResponseEntity<>(r, HttpStatus.OK);
	}

	@Transactional

	@RequestMapping(value = "RemovelinkPromoCode/{promoId}/{clientId}", method = RequestMethod.GET)
	@ApiOperation(value = "linkPromoCode customer")

	public ResponseEntity<?> removeLinkPromoCode(@PathVariable("promoId") Long promoId,
			@PathVariable("clientId") Long clientId)throws BlogNotFoundException {

//		promoService.linkPromocode(promoId,clientId);
		String r = promoService.removelinkPromocode(promoId, clientId);
		return new ResponseEntity<>(r,HttpStatus.OK);
	}

}
