package com.hanlbs.app.controller;

import java.util.UUID;

public class UniqeId {

	
	
//	public static void main(String[] args) {
//		
//		System.out.println(java.util.UUID.randomUUID().toString());
////		System.out.println(java.util.UUID.fromString("hnlns"));
//		
//		
//		String  uniqueKey = ""+Math.random();
//		uniqueKey=uniqueKey.replace(".", "");
//	    System.out.println (uniqueKey);
//		
//	    
//	    
//	}
	
	
	
}
