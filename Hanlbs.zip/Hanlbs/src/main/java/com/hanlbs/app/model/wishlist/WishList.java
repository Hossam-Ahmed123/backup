package com.hanlbs.app.model.wishlist;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "wishlist")
public class WishList {

	@EmbeddedId
	@JsonIgnore
	private WishListPK pk;
 	 
	@Column(nullable = false)
 	private String color;
	private String size;

 

	private String sku;
	private double price;
	private double discount;

	 

	
	
	
 
	private String content;

	public WishList() {
	}

	public WishList(Customer customer, Product product, String color, String size, double price,
			String sKU,ProductMeasurementsSize productSize) {

		pk = new WishListPK();
		pk.setCustomer(customer);
		pk.setProduct(product);
		pk.setSize(productSize);
 		this.color = color;
		this.size = size;
		this.price = price;
		this.sku = sKU;
	}

	@Transient
	public Product getProduct() {
		return pk.getProduct();
	}
	
	
	@Transient
	public ProductMeasurementsSize getProductSize() {
		return pk.getSize();
	}
	


	public WishListPK getPk() {
		return pk;
	}

	public void setPk(WishListPK pk) {
		this.pk = pk;
	}

	 

	 

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

 

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null || getClass() != o.getClass())
			return false;

		WishList that = (WishList) o;
		return Objects.equals(pk.getCustomer().getId(), that.pk.getCustomer().getId())
				&& Objects.equals(getProduct().getId(), that.getProduct().getId());
	}

	 


	
	
	
}
