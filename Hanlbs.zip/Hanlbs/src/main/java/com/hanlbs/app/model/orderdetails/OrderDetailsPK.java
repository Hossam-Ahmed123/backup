package com.hanlbs.app.model.orderdetails;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;
import com.hanlbs.app.model.cart.CartItemPK;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Embeddable

public class OrderDetailsPK implements Serializable {

	@JsonBackReference
	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "product_id")
	private Product product;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "sizeId")
	private ProductMeasurementsSize productSize;
	@Column(name = "order_key")
	private String orderKey;

	public OrderDetailsPK() {

	}

	public OrderDetailsPK(Customer customer, Product product, ProductMeasurementsSize productSize, String key) {
		this.customer = customer;
		this.product = product;
		this.productSize = productSize;
		this.orderKey = key;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ProductMeasurementsSize getProductSize() {
		return productSize;
	}

	public void setProductSize(ProductMeasurementsSize productSize) {
		this.productSize = productSize;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null || getClass() != o.getClass())
			return false;

		OrderDetailsPK that = (OrderDetailsPK) o;
		return Objects.equals(customer, that.customer) && Objects.equals(product, that.product)
				&& Objects.equals(productSize, that.productSize);
	}

	@Override
	public int hashCode() {
		return Objects.hash(customer, product, productSize);
	}

	public String getOrderKey() {
		return orderKey;
	}

	public void setOrderKey(String orderKey) {
		this.orderKey = orderKey;
	}

}
