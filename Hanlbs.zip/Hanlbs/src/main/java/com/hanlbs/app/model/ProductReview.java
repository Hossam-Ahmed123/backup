package com.hanlbs.app.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "product_review")
public class ProductReview {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private long id;
	private String title;
	private int rating;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@Transient
	private transient long productId;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@Transient
	private transient String base64Master;
	
	private String reviewImage;
	
	
	
 
	private  Long clientId;
	
	private  String customerName;

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)

	private Customer customer;

	@ManyToOne
	@JoinColumn(name = "productid")
	private Product products;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date createdAt = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date publishedAt = new Date();
	private String content;

	public ProductReview() {
 		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@JsonIgnore
	public Product getProducts() {
		return products;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public void setProducts(Product products) {

		this.products = products;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getPublishedAt() {
		return publishedAt;
	}

	public void setPublishedAt(Date publishedAt) {
		this.publishedAt = publishedAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@JsonIgnore
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	 
	 
	

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getCustomerName() {

		return customerName;
	}

	public void setCustomerName(String customerName) {
 
		this.customerName = customerName;
	}

	public String getBase64Master() {
		return base64Master;
	}

	public void setBase64Master(String base64Master) {
		this.base64Master = base64Master;
	}

	public String getReviewImage() {
		return reviewImage;
	}

	public void setReviewImage(String reviewImage) {
		this.reviewImage = reviewImage;
	}
	
	
	
	
	
	
	
	
	
	
	
	

}
