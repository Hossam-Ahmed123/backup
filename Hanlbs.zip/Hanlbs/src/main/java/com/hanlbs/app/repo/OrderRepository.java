package com.hanlbs.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.OrderEvents;
import com.hanlbs.app.model.Orders;

@Repository
public interface OrderRepository extends JpaRepository<Orders, Long>, JpaSpecificationExecutor<Orders> {

	List<Orders> findAllByCustomer(Customer customer);

	@Modifying
	@Transactional
	@Query(value = "update orders set status = ?1 where id=?2", nativeQuery = true)

	int updateOrderStatus(String status, long id);

	@Query(value = "select distinct(customer_id) from orders where order_key= ?1", nativeQuery = true)

	Long getCustomerId(String orderKey);

	@Query(value = "select o from OrderEvents o where order_key=:orderKey")

	List<OrderEvents> orderTraking(@Param("orderKey") String orderKey);

}
