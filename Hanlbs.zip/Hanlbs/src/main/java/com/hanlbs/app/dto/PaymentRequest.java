package com.hanlbs.app.dto;

public class PaymentRequest {

	private String profile_id;

	private String tran_type;
	private String tran_class;
	private String cart_description;
	private String cart_id;
	private String cart_currency;
	private double cart_amount;
	private String callback;
	private String retrn;

	public PaymentRequest(String profile_id, String tran_type, String tran_class, String cart_description,
			String cart_id, String cart_currency, double cart_amount, String callback, String retrn) {
		super();
		this.profile_id = profile_id;
		this.tran_type = tran_type;
		this.tran_class = tran_class;
		this.cart_description = cart_description;
		this.cart_id = cart_id;
		this.cart_currency = cart_currency;
		this.cart_amount = cart_amount;
		this.callback = callback;
		this.retrn = retrn;
	}

	public String getProfile_id() {
		return profile_id;
	}

	public void setProfile_id(String profile_id) {
		this.profile_id = profile_id;
	}

	public String getTran_type() {
		return tran_type;
	}

	public void setTran_type(String tran_type) {
		this.tran_type = tran_type;
	}

	public String getTran_class() {
		return tran_class;
	}

	public void setTran_class(String tran_class) {
		this.tran_class = tran_class;
	}

	public String getCart_description() {
		return cart_description;
	}

	public void setCart_description(String cart_description) {
		this.cart_description = cart_description;
	}

	public String getCart_id() {
		return cart_id;
	}

	public void setCart_id(String cart_id) {
		this.cart_id = cart_id;
	}

	public String getCart_currency() {
		return cart_currency;
	}

	public void setCart_currency(String cart_currency) {
		this.cart_currency = cart_currency;
	}

	public double getCart_amount() {
		return cart_amount;
	}

	public void setCart_amount(double cart_amount) {
		this.cart_amount = cart_amount;
	}

	public String getCallback() {
		return callback;
	}

	public void setCallback(String callback) {
		this.callback = callback;
	}

	public String getRetrn() {
		return retrn;
	}

	public void setRetrn(String retrn) {
		this.retrn = retrn;
	}

}
