package com.hanlbs.app.service;

import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.model.Category;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.FlashSale;
import com.hanlbs.app.model.Images;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.ProductReview;
import com.hanlbs.app.repo.CategoryRepo;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.repo.FlashSaleRepository;
import com.hanlbs.app.repo.ImageRepository;
import com.hanlbs.app.repo.ProductMeasurementsSizeRepository;
import com.hanlbs.app.repo.ProductRepository;
import com.hanlbs.app.repo.ProductReviewRepository;
import com.hanlbs.app.utils.ImageImplementaion;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class ProductService {
	private static final Logger logger = LoggerFactory.getLogger(ProductService.class);
	@Value("${image.path}")
	private String imagepath;
	@Autowired
	private ProductRepository repo;

	@Autowired
	CategoryService cserv;
	@Autowired
	private CustomerRepository customerRepo;

	@Autowired
	private ImageRepository imageRepo;
	@Autowired
	private FlashSaleRepository frepo;

	@Autowired
	private ProductMeasurementsSizeRepository sizeRepo;
	@Autowired
	private ProductReviewRepository reviwRepository;

	@Autowired
	BrandService bserv;

	public ProductService(ProductRepository repo) {
		this.repo = repo;
	}

	public Product getProductByID(Long id) {

		logger.info("getProduct by id   service ..... ");

		Product product = repo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));

		return product;
	}

	public Product getProductBySKU(String sku) {

		logger.info("getProduct by SKU   service ..... ");

		return repo.findBySKU(sku);
	}

	public List<Product> getAllProducts() {
		logger.info(" getAllProducts  service ..... ");

		return (List<Product>) repo.findAll();
	}

	public Page<Product> getAllProducts(Pageable pageable) {
		logger.info(" getAllProducts  service ..... ");

		return repo.findAll(pageable);
	}

	public List<Product> getAllProductsWithHigeRate() {
		logger.info(" getAllProductsWithHigeRate  service ..... ");

		return (List<Product>) repo.findBywithInReview();
	}

	public List<Product> getProductByBrand(Long id) {
		logger.info("get Product by Brand id   service ..... " + id);

		return repo.findBybrand(id);
	}

	public List<Product> getProductByCategory(Long id) {
		logger.info("get Product by Category id   service ..... " + id);

		return repo.findByCategory(id);
	}

	public List<Product> getProductByMasterCategory(Long id) {
		logger.info("get Product by Category id   service ..... " + id);

		return repo.findByMasterCategory(id);
	}

	public Product updateProduct(Long id, Product product) throws BlogNotFoundException {
		logger.info("update  Product  service ..... " + id);

		Product oldProduct = getProductByID(id);

		oldProduct.setName(product.getName());
		oldProduct.setDescription(product.getDescription());
		oldProduct.setPrice(product.getPrice());
		oldProduct.setDiscount(product.getDiscount());
		return repo.save(oldProduct);
	}

	public void deleteProduct(Long id) throws java.io.IOException, BlogNotFoundException {
		logger.info("delete   Product  service ..... " + id);
		reviwRepository.deleteRview(id);
		deleteVisicalImages(id);
		imageRepo.deleteImage(id);

		deleteSize(id);

		repo.deleteById(id);
	}

	private void deleteSize(Long id) {
		Product oldProduct = getProductByID(id);

		sizeRepo.deleteByProductID(oldProduct.getId());

	}

	private void deleteVisicalImages(Long id) throws BlogNotFoundException {
		Product oldProduct = getProductByID(id);
		String mImage = oldProduct.getMasterImage();
		mImage.replaceAll("-", "/");
		Path masterImage = Paths.get(imagepath + mImage);
		try {
			boolean result = Files.deleteIfExists(masterImage);

		} catch (IOException e) {
			logger.error("Error  ", e);
		}

		logger.info("delete child image ............> ");
		Set<Images> images = oldProduct.getChildImages();
		for (Images images2 : images) {
			String filepath = images2.getImageName();
			filepath.replaceAll("-", "/");
			Path fileToDeletePath = Paths.get(imagepath + images2.getImageName());
			try {
				boolean result = Files.deleteIfExists(fileToDeletePath);

			} catch (IOException e) {
				logger.error("Error  ", e);
			}

		}

	}

	public void image(Set<Images> img, Product p) throws BlogNotFoundException {
		logger.info("list Product  Child Images ..... ");

		logger.info(" images size  " + img);
		if (img == null || img.size() == 0) {
			logger.info("not found child images");

		} else {
			for (Images image : img) {

				String imageName = "";
				try {
					imageName = new ImageImplementaion().encodeBase64BinarytoFile(image.getBase64(), imagepath);

					logger.info("imageName   " + imageName);

				} catch (Exception e) {
					logger.error("Error", e);
				}
				System.out.println("product id " + p.getId());

				if (imageName == null) {

				} else {
					Images im = new Images(p, imageName);

					imageRepo.save(im);
				}
			}
		}

	}

	public void size(Set<ProductMeasurementsSize> sizeList, Product p) throws BlogNotFoundException {
		logger.info("list Product size service ..... ");

		for (ProductMeasurementsSize siz : sizeList) {
			ProductMeasurementsSize sise = new ProductMeasurementsSize(siz.getSize(), siz.getLength(),
					siz.getShoulder(), siz.getSleevelength(), siz.getBust(), siz.getQuantity(), p, siz.getSizeOrder());
			sizeRepo.save(sise);

		}

	}

	public Product addOneProduct(Product product) throws BlogNotFoundException {
		logger.info("add   Product  service ..... ");

		Category cat = new Category(product.getCategory().getCategoryId(), product.getCategory().getName());
		Brands brand = product.getBrand();
		String imageName = null;
		if (product.getBase64Master() == null) {

		} else {

			try {
				imageName = new ImageImplementaion().encodeBase64BinarytoFile(product.getBase64Master(), imagepath);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
//		String fileName = dateFormat.format(date) + Math.random();
		String uniqueKey = dateFormat.format(date);
		uniqueKey = uniqueKey.replaceAll("-", "");
		uniqueKey = uniqueKey.replaceAll(" ", "");
		Category cate = cserv.getCategoryById(cserv.getMasterCategory(product.getCategory().getCategoryId()));
		Category subcate = cserv.getCategoryById(product.getCategory().getCategoryId());
		Brands brandobj = bserv.getbrandsById(brand.getId());
		String sKU = genrateSKU(brandobj.getsKUCode(), subcate.getsKUCode(), cate.getsKUCode(),
				product.getColorSKUCode()) + uniqueKey;

		Product p = new Product(product.getName(), product.getDescription(), product.getPrice(), product.getAddedOn(),
				sKU, product.getDiscount(), brand, cat, product.getContent(), imageName, product.getColor(),
				product.getColorGroupCode(), product.getColorSKUCode());
		repo.save(p);

		if (product.getChildImages() == null) {

		} else {

			image(product.getChildImages(), p);
		}

		if (product.getChildrenSize() == null) {

		} else {

			size(product.getChildrenSize(), p);
		}

		return p;
	}

	private String genrateSKU(String brand, String scatName, String mainCat, String colorSKU)
			throws BlogNotFoundException {

		String sKU = brand + scatName + mainCat + colorSKU;

		return sKU;
	}

	public List<Product> getTopRatedProductByMasterCategory(Long id) {
		logger.info(" getTopRatedProductByMasterCategory  service ..... ");
		return repo.getTopRatedbyMasterCategory(id);
	}

	public FlashSale getFlashSaleProductByMasterCategory(Long id) {
		logger.info(" getFlashSaleProductByMasterCategory  service ..... ");

		return frepo.findBycategoryid(id);
	}

	public FlashSale getFlashSaleProductByBrand(Long id) {
		logger.info(" getFlashSaleProductByBrand  service ..... ");

		return frepo.findByBrand(id);
	}

	public void addProductFlashsale(long proid, long fid) {
		logger.info("add   Product to flash sale   service ..... ");

		repo.addFlash(proid, fid);

	}

	public void delfromFlash(long proid) {
		logger.info("delete   Product to flash sale   service ..... ");

		repo.updateflashsalebyProdctid(proid);

	}

	public List<Product> getProductswithNoflashSale() {
		// TODO Auto-generated method stub

		return repo.withnoFlash();
	}

	public ProductReview addProductReview(ProductReview review) {

		Product p = repo.findById(review.getProductId());
		Customer cust = customerRepo.findById(review.getClientId())
				.orElseThrow(() -> new BlogNotFoundException("Error"));
		;

		ProductReview rev = new ProductReview();
		rev.setClientId(review.getClientId());
		rev.setContent(review.getContent());
		rev.setCreatedAt(review.getCreatedAt());
		rev.setCustomer(cust);
		rev.setProducts(p);
		rev.setRating(review.getRating());
		 
		try {
			rev.setReviewImage(new ImageImplementaion().encodeBase64BinarytoFile(review.getBase64Master(), imagepath));

		} catch (Exception e) {
			// TODO: handle exception
		}
		rev.setPublishedAt(review.getPublishedAt());
		rev.setTitle(review.getTitle());

		ProductReview pr = reviwRepository.save(rev);

		return pr;

	}

	public List<Product> getmostRecomended(Long pId, Long catId) throws BlogNotFoundException {

		List<Product> list = new ArrayList<Product>();

		List<Product> list1 = repo.findByCategory(catId);
		Product oldProduct = getProductByID(pId);

		for (Product product : list1) {

			if (product.getId() == pId) {

				logger.info("Product name " + oldProduct.getName());
				list.remove(product);
			} else {

				list.add(product);

			}

		}

		return list;
	}

	public ProductMeasurementsSize addSizeForOldProduct(Long id, ProductMeasurementsSize size) {

		logger.info("update  Product Size service ..... " + id);
		ProductMeasurementsSize oldSize = sizeRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));
		;
		oldSize.setSize(size.getSize());
		oldSize.setBust(size.getBust());
		oldSize.setQuantity(size.getQuantity());
		oldSize.setLength(size.getLength());
		oldSize.setSleevelength(size.getSleevelength());
		oldSize.setShoulder(size.getShoulder());
		oldSize.setSizeOrder(size.getSizeOrder());
		return sizeRepo.save(oldSize);

	}

	public ProductMeasurementsSize getSizeobj(Long id) {

		ProductMeasurementsSize oldSize = sizeRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));
		;

		return oldSize;

	}

	public ProductMeasurementsSize updateSize(Long id, ProductMeasurementsSize size) {

		logger.info("update  Product Size service ..... " + id);
		ProductMeasurementsSize oldSize = sizeRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));
		;
		oldSize.setSize(size.getSize());
		oldSize.setBust(size.getBust());
		oldSize.setQuantity(size.getQuantity());
		oldSize.setLength(size.getLength());
		oldSize.setSleevelength(size.getSleevelength());
		oldSize.setShoulder(size.getShoulder());
		oldSize.setSizeOrder(size.getSizeOrder());

		return sizeRepo.save(oldSize);

	}

	public ProductMeasurementsSize addSize(Long productId, ProductMeasurementsSize size) throws BlogNotFoundException {
		Product oldProduct = getProductByID(productId);
		ProductMeasurementsSize oldSize = new ProductMeasurementsSize();
		oldSize.setProduct(oldProduct);
		oldSize.setSize(size.getSize());
		oldSize.setBust(size.getBust());
		oldSize.setQuantity(size.getQuantity());
		oldSize.setLength(size.getLength());
		oldSize.setSleevelength(size.getSleevelength());
		oldSize.setShoulder(size.getShoulder());
		oldSize.setSizeOrder(size.getSizeOrder());

		return sizeRepo.save(oldSize);

	}

	public ProductMeasurementsSize getSize(Long id) {

		ProductMeasurementsSize oldSize = sizeRepo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));
		return oldSize;
	}

	public List<Product> getProductcolorgroupcode(String name) throws BlogNotFoundException {
		logger.info("getProducts in same group   service ..... ");

		return repo.findBycolorgroupcode(name);
	}

	public List<Product> homeSearch(String name) {

		logger.info("getProduct by Name   service ..... ");

		return repo.findByName(name);
	}

	public Product getProductByName(String name) {

		logger.info("getProduct by Name   service ..... ");

		return repo.SearchByNAme(name);
	}

	public List<Product> getProductByPriceRange(double p1, double p2) {

		logger.info("getProduct by Name   service ..... ");

		return repo.findByPrice(p1, p2);
	}
}
