package com.hanlbs.app.dto;

public class WishListDto {

	private Long clinetId;
	private Long ProductId;

	private Long sizeId;

	public Long getClinetId() {
		return clinetId;
	}

	public void setClinetId(Long clinetId) {
		this.clinetId = clinetId;
	}

	public Long getProductId() {
		return ProductId;
	}

	public void setProductId(Long productId) {
		ProductId = productId;
	}

	public Long getSizeId() {
		return sizeId;
	}

	public void setSizeId(Long sizeId) {
		this.sizeId = sizeId;
	}

}
