package com.hanlbs.app.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.repo.BrandRepo;
import com.hanlbs.app.utils.ImageImplementaion;

@Service
public class BrandService {
	@Value("${image.path}")
	private String imagepath;
	private static final Logger logger = LoggerFactory.getLogger(BrandService.class);

	@Autowired
	BrandRepo repo;

	public List<Brands> getbrands() {
		logger.info("get brands  from brands service ..... ");

		List<Brands> list = new ArrayList<Brands>();

		list = repo.findAll();

		return list;

	}

	public Brands getbrandsById(int id) {
		logger.info("get brands  from brands service ..... ");

		return repo.findById(id).orElseThrow(() -> new BlogNotFoundException("brand by id " + id + " was not found."));
	}

	public Brands addBrands(Brands brand) throws BlogNotFoundException{

		logger.info("save brands from brands service ..... ");

		Brands newBrand = new Brands();
		newBrand.setName(brand.getName());
		if (brand.getBase64Master() == null || brand.getBase64Master().isEmpty()) {

		} else {
			newBrand.setBrandImage(
					new ImageImplementaion().encodeBase64BinarytoFile(brand.getBase64Master(), imagepath));

		}
		newBrand.setsKUCode(brand.getsKUCode());

		return repo.save(newBrand);
	}

	public Brands editBrands(Brands brand) throws BlogNotFoundException{

		logger.info("Update brands from brands service ..... ");

		Brands newBrand = repo.findById(brand.getId())
				.orElseThrow(() -> new BlogNotFoundException("Brand by id " + brand.getId() + " was not found."));

		newBrand.setName(brand.getName());
		if (brand.getBase64Master() == null) {

		} else {
			newBrand.setBrandImage(
					new ImageImplementaion().encodeBase64BinarytoFile(brand.getBase64Master(), imagepath));

		}

		newBrand.setsKUCode(brand.getsKUCode());
		return repo.save(newBrand);
	}

}
