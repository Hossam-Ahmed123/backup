package com.hanlbs.app.service.payment;

import com.google.gson.Gson;
import com.hanlbs.app.dto.PaymentDTO;
import com.hanlbs.app.dto.PaymentRequest;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Orders;
import com.hanlbs.app.model.cart.CartItem;

import org.apache.commons.codec.binary.Hex;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.UUID;

@Service
public class PaymentServiceRequest {
 

	public TreeMap callPaymentAPI(Customer customer, String orderKey, PaymentDTO payment ,String returnUrl,String callbackUrl,String cancelUrl) throws Exception {
		Gson gson = new Gson();
		TreeMap order = new TreeMap<>();
		order.put("country", "EG");
		order.put("reference", orderKey);
		double am = payment.getTotalAmount() * 100;
		TreeMap amount = new TreeMap<>();
		amount.put("currency", "EGP");
		amount.put("total", am);
		order.put("amount", amount);
		order.put("returnUrl", returnUrl);
		order.put("callbackUrl", callbackUrl);
		order.put("cancelUrl", cancelUrl);
		order.put("expireAt", new Integer(500));
//		TreeMap userInfo = new TreeMap<>();
//		userInfo.put("userEmail", "xxx@xxx.com");
//		userInfo.put("userId", "userid001");
//		userInfo.put("userMobile", "13056288895");
//		userInfo.put("userName", "xxx");
//		order.put("userInfo", userInfo);
		ArrayList productList = new ArrayList<>();
		for (CartItem c : customer.getCartItems()) {
			TreeMap product = new TreeMap<>();
			product.put("productId", c.getProduct().getId());
			product.put("name", c.getProduct().getName());
			product.put("description", c.getProduct().getDescription());
			product.put("price", c.getProduct().getPrice());
			product.put("quantity", new Integer(2));
			product.put("imageUrl", "https://imageUrl.com");
			productList.add(product);

		}
		order.put("productList", productList);
		order.put("payMethod", "BankCard");

		String requestBody = gson.toJson(order);
		System.out.println("--request:");
		System.out.println(requestBody);

//		URL url = new URL(addr);
//		HttpURLConnection con = (HttpURLConnection) url.openConnection();
//		con.setRequestMethod("POST");
//		con.setRequestProperty("Content-Type", "application/json; utf-8");
//		con.setRequestProperty("Authorization", "Bearer " + publicKey);
//		con.setRequestProperty("MerchantId", merchantId);
//		con.setDoOutput(true);
//		OutputStream os = con.getOutputStream();
//		byte[] input = requestBody.getBytes(StandardCharsets.UTF_8);
//		os.write(input, 0, input.length);
//		BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8));
//		StringBuilder response = new StringBuilder();
//		String responseLine = null;
//		while ((responseLine = br.readLine()) != null) {
//			response.append(responseLine.trim());
//		}
//
//		System.out.println("--response:");
//		System.out.println(response);

		return order;
		// close your stream and connection
	}

//
//	public static String hmacSHA512(final String data, final String secureKey) throws Exception {
//		byte[] bytesKey = secureKey.getBytes();
//		final SecretKeySpec secretKey = new SecretKeySpec(bytesKey, "HmacSHA512");
//		Mac mac = Mac.getInstance("HmacSHA512");
//		mac.init(secretKey);
//		final byte[] macData = mac.doFinal(data.getBytes());
//		byte[] hex = new Hex().encode(macData);
//		return new String(hex, StandardCharsets.UTF_8);
//	}
}