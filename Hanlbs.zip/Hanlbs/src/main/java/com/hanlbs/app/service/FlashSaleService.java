package com.hanlbs.app.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.FlashSale;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.repo.FlashSaleRepository;
import com.hanlbs.app.repo.ProductRepository;

@Service
public class FlashSaleService {

	private static final Logger logger = LoggerFactory.getLogger(FlashSaleService.class);

	@Autowired
	private FlashSaleRepository repo;
	@Autowired
	private ProductRepository prepo;

	public FlashSale getFlashSaleByID(Long id) {

		logger.info("getFlash Sale by id   service ..... ");

		return repo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Flash Sale  by id " + id + " was not found."));
	}

	public FlashSale addFlashSale(FlashSale flashSale) throws BlogNotFoundException{

		FlashSale f = repo.save(flashSale);

		return f;
	}

	public FlashSale updateFlashSale(Long id, FlashSale flashSale)throws BlogNotFoundException {
		logger.info("update  FlashSale  service ..... " + id);

		FlashSale oldsale = getFlashSaleByID(id);
		oldsale.setName(flashSale.getName());
		oldsale.setDiscription(flashSale.getDiscription());
		oldsale.setStart(flashSale.getStart());
		oldsale.setEnd(flashSale.getEnd());

		return repo.save(oldsale);
	}

//
	public void deleteFlashSale(Long id) throws BlogNotFoundException{

		FlashSale flashSale = repo.findByprimId(id);

		for (Product iterable_element : flashSale.getFlashSaleProducts()) {
			prepo.updateflashsale(id);

		}

		repo.deleteByprimId(id);
	}

	
	
	public List<FlashSale> getAllflashSale() throws BlogNotFoundException{
		logger.info(" getAllflashSale  service ..... ");
		return (List<FlashSale>) repo.findAll();
	}
	 

}
