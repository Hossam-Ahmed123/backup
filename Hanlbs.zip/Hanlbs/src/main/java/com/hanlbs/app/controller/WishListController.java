package com.hanlbs.app.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.hanlbs.app.dto.WishListDTO;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
 
import com.hanlbs.app.model.wishlist.WishList;

import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.ProductService;
import com.hanlbs.app.service.WishListService;

import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/CustomerWishList")
public class WishListController {
	private static final Logger logger = LoggerFactory.getLogger(APIController.class);

	@Autowired

	private ProductService productService;
	@Autowired

	private WishListService wishListService;
	@Autowired

	private CustomerService customerService;

	@GetMapping("/customer/{id}/wishList")
	@ApiOperation(value = "Get User WishList")
	public ResponseEntity<List<WishList>> getUserWishList(@PathVariable("id") Long id) {
		logger.info("get User WishList by userId Controler ..... ");

		return new ResponseEntity<>(customerService.getCustomerById(id).getWishList(), HttpStatus.OK);
	}

	@PostMapping("/addToWishList")
	@ApiOperation(value = "ADD User WishList")

	public ResponseEntity<Customer> addToUserWishList(@RequestBody WishListDTO wishList) {
		Customer customer = customerService.getCustomerById(wishList.getCustomerId());
		Product product = productService.getProductByID(wishList.getProductId());
		ProductMeasurementsSize productSize = productService.getSizeobj(wishList.getSizeId());

		logger.info("addTo customer wishList  Controler ..... ");

		WishList wish = new WishList(customer, product, wishList.getColor(), wishList.getSize(), wishList.getPrice(),
				wishList.getSku(), productSize);
		wishListService.addWishList(wish);

		return new ResponseEntity<>(customerService.getCustomerById(wishList.getCustomerId()), HttpStatus.CREATED);
	}

	@DeleteMapping("/customer/{id}/WishList/remove/{productId}/{sizeid}")
	@ApiOperation(value = "Remove User WishList")

	public ResponseEntity<Customer> removeFromUserWishList(@PathVariable("id") Long id,
			@PathVariable("productId") Long productId, @PathVariable("sizeid") Long sizeid) {

		logger.info("remove From User Cart Controler ..... ");

		wishListService.deleteWishList(id, productId, sizeid);

		return new ResponseEntity<>(customerService.getCustomerById(id), HttpStatus.OK);
	}


	
}
