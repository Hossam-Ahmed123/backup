package com.hanlbs.app.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "payment_methods")
public class PaymentMethod implements Serializable {

	private static final long serialVersionUID = -6571020025726257848L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	private long id;

	@OneToOne
	private Customer customr;

	private String cardNumber;
	private String expirDate;
	private String secureNumber;
	private String otherData;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Customer getCustomr() {
		return customr;
	}
	public void setCustomr(Customer customr) {
		this.customr = customr;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getExpirDate() {
		return expirDate;
	}
	public void setExpirDate(String expirDate) {
		this.expirDate = expirDate;
	}
	public String getSecureNumber() {
		return secureNumber;
	}
	public void setSecureNumber(String secureNumber) {
		this.secureNumber = secureNumber;
	}
	public String getOtherData() {
		return otherData;
	}
	public void setOtherData(String otherData) {
		this.otherData = otherData;
	}
	
	
	
	
	
	
	
	
	
	
	

}
