package com.hanlbs.app.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "category")

public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long categoryId;
	private String name;
	private String coverPhoto;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@Transient
	private transient String base64cover;
	private String sKUCode;
	
	
	
	@ManyToOne(optional = true, fetch = FetchType.LAZY)
	@JoinColumn(name = "parencatid", referencedColumnName = "categoryId")
	private Category parent;@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	@Transient
	private transient long parentCategoryId;

	@OneToMany(cascade = { CascadeType.ALL }, orphanRemoval = true, fetch = FetchType.LAZY)
	@JoinColumn(name = "parencatid")
	private List<Category> childrenCategories;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "category")

	private Set<Product> childrenProducts;

	public Category() {
	}

	public Category(long categoryId, String name) {
		super();
		this.categoryId = categoryId;
		this.name = name;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Category> getChildrenCategories() {
		return childrenCategories;
	}

	public void setChildrenCategories(List<Category> childrenCategories) {
		this.childrenCategories = childrenCategories;
	}

	public String getCoverPhoto() {
		return coverPhoto;
	}

	public void setCoverPhoto(String coverPhoto) {
		this.coverPhoto = coverPhoto;
	}

	public String getBase64cover() {
		return base64cover;
	}

	public void setBase64cover(String base64cover) {
		this.base64cover = base64cover;
	}

	public long getParentCategoryId() {
		return parentCategoryId;
	}

	public void setParentCategoryId(long parentCategoryId) {
		this.parentCategoryId = parentCategoryId;
	}

	public String getsKUCode() {
		return sKUCode;
	}

	public void setsKUCode(String sKUCode) {
		this.sKUCode = sKUCode;
	}
	
	

}
