package com.hanlbs.app.dto;

public class PaymentDTO {

	private double totalAmount;
	private long customerId;
	private double subtotal;

	public double getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(double subtotal) {
		this.subtotal = subtotal;
	}

	private double shppingFees;
	private double promoCode;

	public double getShppingFees() {
		return shppingFees;
	}

	public void setShppingFees(double shppingFees) {
		this.shppingFees = shppingFees;
	}

	public double getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(double promoCode) {
		this.promoCode = promoCode;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

}
