package com.hanlbs.app.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hanlbs.app.dto.CartDTO;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.cart.CartItemPK;
import com.hanlbs.app.service.CartItemService;
import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.ProductService;

@RestController
@CrossOrigin
@RequestMapping("/cart")
public class CartItemController {
	private static final Logger logger = LoggerFactory.getLogger(APIController.class);

	@Autowired

	private ProductService productService;
	@Autowired

	private CartItemService cartItemService;
	@Autowired

	private CustomerService customerService;

	@GetMapping("/customer/{id}/cart")
	public ResponseEntity<List<CartItem>> getUserCart(@PathVariable("id") Long id) {
		logger.info("get User Cart by userId Controler ..... ");

		return new ResponseEntity<>(customerService.getCustomerById(id).getCartItems(), HttpStatus.OK);
	}

	@PostMapping("/addTocart")
	public ResponseEntity<Customer> addToUserCart(@RequestBody CartDTO cart) {
		Customer customer = customerService.getCustomerById(cart.getCustomerId());
		Product product = productService.getProductByID(cart.getProductId());
		ProductMeasurementsSize productSize = productService.getSizeobj(cart.getSizeId());

		logger.info("addTo customer Cart  Controler ..... ");

		CartItem cartItem = new CartItem(customer, product, cart.getQuantity(), cart.getColor(), cart.getSize(),
				cart.getPrice(), cart.getSku(), productSize);
		cartItemService.addCartItem(cartItem);

		return new ResponseEntity<>(customerService.getCustomerById(cart.getCustomerId()), HttpStatus.CREATED);
	}

	@PutMapping("/customer/{id}/cart/update/{productId}/{sizeid}")
	public ResponseEntity<Customer> updateCartItem(@PathVariable("id") Long id,
			@PathVariable("productId") Long productId, @PathVariable("sizeid") Long sizeId,
			@RequestBody CartItem cartItem) {
		Customer customer = customerService.getCustomerById(id);
		logger.info("update Cart Item  Controler ..... ");

		Product product = productService.getProductByID(productId);
		ProductMeasurementsSize pSize = productService.getSize(sizeId);

		CartItem newCart = new CartItem();
		newCart.setQuantity(cartItem.getQuantity());

		newCart.setPk(new CartItemPK(customer, product, pSize));
		cartItemService.updateCartItem(newCart);

		return new ResponseEntity<>(customerService.getCustomerById(id), HttpStatus.OK);
	}

	@DeleteMapping("/customer/{id}/cart/remove/{productId}/{sizeid}")
	public ResponseEntity<Customer> removeFromUserCart(@PathVariable("id") Long id,
			@PathVariable("productId") Long productId, @PathVariable("sizeid") Long sizeid) {

		logger.info("remove From User Cart Controler ..... ");

		cartItemService.deleteCartItem(id, productId, sizeid);

		return new ResponseEntity<>(customerService.getCustomerById(id), HttpStatus.OK);
	}

	@GetMapping("/cart-items")
	public ResponseEntity<List<CartItem>> getCartItems() {

		logger.info("getCartItems Controler ..... ");

		return ResponseEntity.ok(cartItemService.getCartItems());
	}

	@GetMapping("/cart-items/{id}/{productId}")
	public ResponseEntity<CartItem> getCartItem(@PathVariable("id") Long id,
			@PathVariable("productId") Long productId) {

		logger.info("getCartItems by cart id Controler ..... ");

		return ResponseEntity.ok(cartItemService.getCartItem(id, productId));
	}
}
