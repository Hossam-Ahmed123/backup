package com.hanlbs.app.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.hanlbs.app.model.orderdetails.OrderDetails;

@Entity
@Table(name = "ProductMeasurementsSize")
@JsonPropertyOrder


public class ProductMeasurementsSize {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String size;
	private int quantity;
	private double length;
	private double shoulder;
	private double sleevelength;
	private double bust;
	private int sizeOrder;

	@ManyToOne
	@JoinColumn(name = "productid")
	private Product product;
	
	@JsonIgnore
	@OneToMany(mappedBy = "pk.productSize", cascade = CascadeType.ALL)
	private List<OrderDetails> orderDetails = new ArrayList<>();
	

	public ProductMeasurementsSize() {
		// TODO Auto-generated constructor stub
	}

	public ProductMeasurementsSize(String size, double length, double shoulder, double sleevelength, double bust,
			int quantity, Product product,int sizeOrder) {
		super();
		this.size = size;
		this.length = length;
		this.shoulder = shoulder;
		this.sleevelength = sleevelength;
		this.bust = bust;
		this.quantity = quantity;
		this.product = product;
		this.sizeOrder=sizeOrder;

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public double getShoulder() {
		return shoulder;
	}

	public void setShoulder(double shoulder) {
		this.shoulder = shoulder;
	}

	public double getSleevelength() {
		return sleevelength;
	}

	public void setSleevelength(double sleevelength) {
		this.sleevelength = sleevelength;
	}

	public double getBust() {
		return bust;
	}

	public void setBust(double bust) {
		this.bust = bust;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@JsonIgnore
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	
	
	public int getSizeOrder() {
		return sizeOrder;
	}

	public void setSizeOrder(int sizeOrder) {
		this.sizeOrder = sizeOrder;
	}

}
