package com.hanlbs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.UserNotFoundException;
import com.hanlbs.app.model.COD;
import com.hanlbs.app.repo.CODRepsitory;

@Service
public class CODService {

	@Autowired
	CODRepsitory repo;

	public boolean addCOD(double fees, boolean active) {

		COD cod = new COD();
		cod.setFees(fees);
		cod.setAcitveCOD(active);
		COD add = repo.save(cod);
		if (add == null) {
			return false;
		} else {
			return true;
		}

	}

	public boolean editCOD(double fees, boolean active, Long id) {
		COD cod = repo.findById(id).orElseThrow(() -> new UserNotFoundException(" id " + id + " was not found."));
		cod.setFees(fees);
		cod.setAcitveCOD(active);
		COD add = repo.save(cod);
		if (add == null) {
			return false;
		} else {
			return true;
		}

	}

	public COD findById(Long id) {

		return repo.findById(id).orElseThrow(() -> new UserNotFoundException(" id " + id + " was not found."));

	}

	public List<COD> AllCOD() {

		return repo.findAll();
	}

}
