package com.hanlbs.app.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hanlbs.app.dto.CustomerDTO;
import com.hanlbs.app.dto.WishListDto;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.exceptions.UserNotFoundException;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.repo.OrderRepository;

@Service
public class CustomerService {
	private final CustomerRepository repo;
	private static final Logger logger = LoggerFactory.getLogger(UserService.class);
	@Autowired
	private OrderRepository oRpo;

	public CustomerService(CustomerRepository repo) {
		this.repo = repo;
	}

	public List<Customer> getCustomer() {
		logger.info("List All Customer from user service ..... ");

		return repo.all();
	}

	@Autowired
	private PasswordEncoder bcryptEncoder;

	public Customer getCustomerById(Long id) {

		logger.info("List Customer by id from user service ..... ");

		return repo.findById(id).orElseThrow(() -> new UserNotFoundException("User by id " + id + " was not found."));
	}

	public Customer updateCustomerById(CustomerDTO cust, Long id) throws BlogNotFoundException {

		logger.info("update Customer by id from user service ..... ");

		Customer c = getCustomerById(id);
		if (cust.getPhone() == null) {

		} else {
			c.setPhone(cust.getPhone());
		}

		if (cust.getName() == null) {

		} else {
			c.setName(cust.getName());
		}

		 

		return repo.save(c);
	}

	public Customer getOrderCustomerDetails(String orderKey) {
		Long id = oRpo.getCustomerId(orderKey);
		Customer c = getCustomerById(id);

		return c;
	}

	public int addWishList(WishListDto wishList) throws BlogNotFoundException {

		return repo.addLikes(wishList.getClinetId(), wishList.getProductId(), wishList.getSizeId());
	}

	public int removeWishList(Long custId, Long productID, Long sizeId) {

		return repo.removeLikes(custId, productID, sizeId);

	}

}
