package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.ShippingFees;

@Repository
public interface ShippingFeesRepository extends JpaRepository<ShippingFees, Long> {

	
	
	@Query(value = "select  value shippingfees WHERE city =:city", nativeQuery = true)

	double findShippingFeesbyCity(@Param("city") String city);

}
