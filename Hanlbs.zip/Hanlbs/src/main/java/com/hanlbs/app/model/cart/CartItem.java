package com.hanlbs.app.model.cart;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Table(name = "cart_item")
public class CartItem {

	@EmbeddedId
	@JsonIgnore
	private CartItemPK pk;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date addedOn = new Date();
	@Column(nullable = false)
	private int quantity = 1;
	private String color;
	private String size;

	public int getActive() {
		return active;
	}

	public void setActive(int active) {
		this.active = active;
	}

	private String sku;
	private double price;
	private double discount;

	private boolean isOrdered;
	private String orderKey;

//	@ManyToOne
//	@JsonIgnore
//	private Orders order;

	private int active;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date createdAt = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date updatedAt = new Date();
	private String content;

	public CartItem() {
	}

	public CartItem(Customer customer, Product product, int quantity, String color, String size, double price,
			String sKU, ProductMeasurementsSize productSize) {
		this();
		pk = new CartItemPK();
		pk.setCustomer(customer);
		pk.setProduct(product);
		pk.setSize(productSize);
		this.quantity = quantity;
		this.color = color;
		this.size = size;
		this.price = price;
		this.sku = sKU;
	}

	@Transient
	public Product getProduct() {
		return pk.getProduct();
	}

	@Transient
	public ProductMeasurementsSize getProductSize() {
		return pk.getSize();
	}

	@Transient
	public double getTotalPrice() {
		return Math.round(quantity * getProduct().getPriceAfterDiscount());
	}

	public CartItemPK getPk() {
		return pk;
	}

	public void setPk(CartItemPK pk) {
		this.pk = pk;
	}

	public Date getAddedOn() {
		return addedOn;
	}

	public void setAddedOn(Date addedOn) {
		this.addedOn = addedOn;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null || getClass() != o.getClass())
			return false;

		CartItem that = (CartItem) o;
		return Objects.equals(pk.getCustomer().getId(), that.pk.getCustomer().getId())
				&& Objects.equals(getProduct().getId(), that.getProduct().getId());
	}

	public boolean isOrdered() {
		return isOrdered;
	}

	public void setOrdered(boolean isOrdered) {
		this.isOrdered = isOrdered;
	}

	public String getOrderKey() {
		return orderKey;
	}

	public void setOrderKey(String orderKey) {
		this.orderKey = orderKey;
	}

}
