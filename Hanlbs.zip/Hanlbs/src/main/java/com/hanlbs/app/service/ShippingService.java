package com.hanlbs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.UserNotFoundException;
import com.hanlbs.app.model.shipping.City;
import com.hanlbs.app.model.shipping.Country;
import com.hanlbs.app.repo.CityRepository;
import com.hanlbs.app.repo.CountryRepository;

@Service
public class ShippingService {

	@Autowired
	CountryRepository countryRepository;
	@Autowired
	CityRepository cityRepository;

	public List<Country> allCountries() {

		return countryRepository.findAll();

	}

	public City addCity(String CityName, double fees, Country country) {

		City city = cityRepository.findByName(CityName);
		if (city == null) {
			City newCity = new City();
			newCity.setCountry(country);
			newCity.setShippingFees(fees);
			newCity.setName(CityName);
			newCity.setActive(true);
			newCity.setAddBefore(false);
			newCity.setEditBefore(false);
			return cityRepository.save(newCity);

		} else {

			city.setAddBefore(true);
			return cityRepository.save(city);

		}

	}

	public boolean removeCity(Long id) {

		int result = cityRepository.remove(id);
		if (result > 0) {
			return true;
		} else {
			return false;
		}

	}

	public City editCity(Long id, double fees, int active) {

		City city = cityRepository.findById(id)
				.orElseThrow(() -> new UserNotFoundException("City by id " + id + " was not found."));

		city.setShippingFees(fees);

		if (active == 1) {
			city.setActive(true);
			city.setEditBefore(true);

		} else {
			city.setEditBefore(true);

			city.setActive(false);

		}
//		city.setActive(isActive);

		return cityRepository.save(city);

	}

	public Country activateCountry(Long id, int activate) {

		Country country = countryRepository.findById(id)
				.orElseThrow(() -> new UserNotFoundException("City by id " + id + " was not found."));
		if (activate == 1) {

			country.setActive(true);
			country.setEditBefore(true);

			return countryRepository.save(country);
		} else {
			country.setEditBefore(true);

			country.setActive(false);
			return countryRepository.save(country);
		}

	}

	public Country addCountry(String countryName, String shortName) {

		Country country = countryRepository.findByName(countryName);
		if (country == null) {
			Country newCountry = new Country();
			newCountry.setCountry(countryName);
			newCountry.setCountryShortName(shortName);
			newCountry.setActive(true);
			newCountry.setEditBefore(false);

			return countryRepository.save(newCountry);
		} else {
			return country;
		}

	}

	public City cityByID(Long id) {
		// TODO Auto-generated method stub
		return cityRepository.findById(id)
				.orElseThrow(() -> new UserNotFoundException("City by id " + id + " was not found."));
		
	}

}
