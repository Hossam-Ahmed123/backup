package com.hanlbs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.ShippingFees;
import com.hanlbs.app.repo.ShippingFeesRepository;

@Service
public class ShippingFeesService {

	@Autowired
	ShippingFeesRepository repo;

	public ShippingFees addShippingFees(ShippingFees fess) {

		return repo.save(fess);

	}

	public ShippingFees editShippingFees(ShippingFees fess, long id) throws BlogNotFoundException{

		ShippingFees oldFees = repo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException(" by id " + id + " was not found."));

		oldFees.setValue(fess.getValue());

		return repo.save(oldFees);

	}

	public double shippingFeesValue(String city) {

		return repo.findShippingFeesbyCity(city);

	}

	public ShippingFees ShippingFees(long id)throws BlogNotFoundException {

		return repo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("fess by id " + id + " was not found."));

	}

	public List<ShippingFees> allShippingFees() {

		return repo.findAll();

	}

}
