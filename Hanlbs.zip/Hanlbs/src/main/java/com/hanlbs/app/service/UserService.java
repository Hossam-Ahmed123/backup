package com.hanlbs.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.exceptions.UserNotFoundException;
import com.hanlbs.app.model.User;
import com.hanlbs.app.repo.UserRepository;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class UserService {
	private final UserRepository repo;
	private static final Logger logger = LoggerFactory.getLogger(UserService.class);

	public UserService(UserRepository repo) {
		this.repo = repo;
	}

	public List<User> getUsers() {
		logger.info("List All users from user service ..... ");

		return repo.findAll();
	}

	@Autowired
	private PasswordEncoder bcryptEncoder;

	public User getUser(Long id) {

		logger.info("List users by id from user service ..... ");

		return repo.findById(id).orElseThrow(() -> new UserNotFoundException("User by id " + id + " was not found."));
	}

	public User updateUser(Long id, User user)throws BlogNotFoundException {
		User oldUser = getUser(id);
		logger.info("update  user by id from user service ..... ");

		oldUser.setUsername(user.getUsername());
		oldUser.setEmail(user.getEmail());
		oldUser.setAddress(user.getAddress());
		oldUser.setName(user.getName());
		oldUser.setPhone(user.getPhone());

		return repo.save(oldUser);
	}

	public void deleteUser(Long id) throws BlogNotFoundException{
		logger.info("delete  user by id from user service ..... ");

		repo.deleteById(id);
	}
}
