package com.hanlbs.app.model.cart;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CartItemPK implements Serializable {

	@JsonBackReference
	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "customer_id")
	private Customer customer;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "product_id")
	private Product product;

	@ManyToOne(optional = false, fetch = FetchType.LAZY)
	@JoinColumn(name = "size_id")
	private ProductMeasurementsSize size;

	public CartItemPK() {

	}

	public CartItemPK(Customer customer, Product product, ProductMeasurementsSize size) {
		this.customer = customer;
		this.product = product;
		this.size = size;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ProductMeasurementsSize getSize() {
		return size;
	}

	public void setSize(ProductMeasurementsSize size) {
		this.size = size;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;

		if (o == null || getClass() != o.getClass())
			return false;

		CartItemPK that = (CartItemPK) o;
		return Objects.equals(customer, that.customer) && Objects.equals(product, that.product)
				&& Objects.equals(size, that.size);
	}

	@Override
	public int hashCode() {
		return Objects.hash(customer, product, size);
	}

}
