package com.hanlbs.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.cart.CartItemPK;
import com.hanlbs.app.model.orderdetails.OrderDetails;
import com.hanlbs.app.model.wishlist.WishList;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false, length = 128)
	private String password;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "customer")
	private List<PromoCode> promoCode;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
	private List<ProductReview> review;

	@Column(unique = true, nullable = false, length = 100)
	private String email;

	@Column(nullable = false, length = 100)
	private String name;

	@Column(nullable = false, length = 15)
	private String phone;

	private boolean vendor;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date registeredAt = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date lastLogin = new Date();

	private String intro;
	private String profile;
	@JsonManagedReference
	@OneToOne(mappedBy = "customer")
	private ShippingInfo shipping;
	@JsonManagedReference
	@OneToMany(mappedBy = "pk.customer", cascade = CascadeType.ALL)
	private List<CartItem> cartItems = new ArrayList<>();
	@JsonManagedReference
	@OneToMany(mappedBy = "pk.customer", cascade = CascadeType.ALL)
	private List<WishList> wishList = new ArrayList<>();

	@OneToMany(mappedBy = "pk.customer", cascade = CascadeType.ALL)
	private List<OrderDetails> orderDetails = new ArrayList<>();

	public Customer(String password, String email, String name, String phone) {

		this.password = password;
		this.email = email;
		this.name = name;

		this.phone = phone;
	}

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public List<WishList> getWishList() {
		return wishList;
	}

	public void setWishList(List<WishList> wishList) {
		this.wishList = wishList;
	}

	public List<CartItem> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<CartItem> cartItems) {
		this.cartItems = cartItems;
	}

	@Transient
	public double getCartTotal() {
		double sum = 0;

		for (CartItem item : cartItems) {

			sum += item.getTotalPrice();

		}
		return sum;
	}

//	@JsonIgnore
//	public ProductReview getReview() {
//		return review;
//	}
//
//	public void setReview(ProductReview review) {
//		this.review = review;
//	}

	@JsonIgnore
	public List<ProductReview> getReview() {
		return review;
	}

	public void setReview(List<ProductReview> review) {
		this.review = review;
	}

	public ShippingInfo getShipping() {
		return shipping;
	}

	public void setShipping(ShippingInfo shipping) {
		this.shipping = shipping;
	}

	public List<PromoCode> getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(List<PromoCode> promoCode) {
		this.promoCode = promoCode;
	}

	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

}
