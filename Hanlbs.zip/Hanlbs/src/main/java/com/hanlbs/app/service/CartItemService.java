package com.hanlbs.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.config.JwtAuthenticationEntryPoint;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.exceptions.CartItemAlreadyExistsException;
import com.hanlbs.app.exceptions.CartItemDoesNotExistsException;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.repo.CartItemRepository;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class CartItemService {
	private static final Logger logger = LoggerFactory.getLogger(CartItemService.class);

	@Autowired
	private CartItemRepository repo;

	public CartItemService(CartItemRepository repo) {
		this.repo = repo;
	}

	public List<CartItem> getCartItems() {
		return repo.findAll();
	}

	public CartItem getCartItem(Long customerId, Long productId) {
		logger.info("get CartItem by  userId and productId service ..... " + customerId);

		for (CartItem item : getCartItems()) {
			if (item.getPk().getCustomer().getId() == customerId && item.getPk().getProduct().getId() == productId) {
				return item;
			}
		}

		throw new CartItemDoesNotExistsException(
				"Cart item w/ user id " + customerId + " and product id " + productId + " does not exist.");
	}

//	public CartItem getCartItemByID(Long cartID) {
//		logger.info("get CartItem by  userId and productId service ..... " + cartID);
//
//		return repo.findById(cartID)
//				.orElseThrow(() -> new ProductNotFoundException("Product by id " + cartID + " was not found."));
//
//	}

	public CartItem addCartItem(CartItem cartItem) throws BlogNotFoundException {
		logger.info("add CartItem service ..... ");

		for (CartItem item : getCartItems()) {
			if (item.getPk().getCustomer().equals(cartItem.getPk().getCustomer())
					&& item.getPk().getProduct().equals(cartItem.getPk().getProduct())
					&& item.getPk().getSize().equals(cartItem.getPk().getSize())) {
				throw new CartItemAlreadyExistsException(
						"Cart item w/ user id " + cartItem.getPk().getCustomer().getId() + " and product id "
								+ cartItem.getProduct().getId() + " already exists.");
			}
		}

		return this.repo.save(cartItem);
	}

	public CartItem updateCartItem(CartItem cartItem) throws BlogNotFoundException {
		logger.info("update CartItem  service ..... ");

		for (CartItem item : getCartItems()) {
			if (item.getPk().getCustomer().getId() == cartItem.getPk().getCustomer().getId()
					&& item.getPk().getProduct().getId() == cartItem.getPk().getProduct().getId()
					&& item.getPk().getSize().getId() == cartItem.getPk().getSize().getId()) {
				item.setQuantity(cartItem.getQuantity());
				return repo.save(item);
			}
		}

		throw new CartItemDoesNotExistsException("Cart item w/ user id " + cartItem.getPk().getCustomer().getId()
				+ " and product id " + cartItem.getProduct().getId() + " does not exist.");
	}

	public int updateCartItemAfterOrder(Long clientId, String orderdKey) throws BlogNotFoundException {
		logger.info("update CartItem  service ..... ");

		return 0;

	}

	public void deleteCartItem(Long userId, Long productId, Long sizeID) throws BlogNotFoundException {
		logger.info("Delete CartItem  service ..... ");

		for (CartItem item : getCartItems()) {
			if (item.getPk().getCustomer().getId() == userId && item.getPk().getProduct().getId() == productId
					&& item.getPk().getSize().getId() == sizeID) {
				repo.delete(item);
				return;
			}
		}

		throw new CartItemDoesNotExistsException(
				"Cart item w/ user id " + userId + " and product id " + productId + " does not exist.");
	}
}
