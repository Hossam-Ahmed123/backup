package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.FlashSale;

@Repository
public interface FlashSaleRepository extends CrudRepository<FlashSale, Long> {

	@Modifying
	@Transactional
	@Query(value = "DELETE from flash_sale WHERE id =:c_id", nativeQuery = true)
	void deleteByprimId(@Param("c_id") long id);

	@Query(value = "SELECT * FROM flash_sale u WHERE u.id =:c_id", nativeQuery = true)
	FlashSale findByprimId(@Param("c_id") long id);

	
	
	@Query(value = "SELECT * FROM flash_sale u  inner join products p inner join  category cat on p.flashsaleid=u.id and  p.categoryid = cat.category_id and cat.parencatid =:c_id", nativeQuery = true)
	FlashSale findBycategoryid(@Param("c_id") long id);

	
	@Query(value = "SELECT * FROM flash_sale u  inner join products p inner join  brands cat on p.flashsaleid=u.id and  p.brandid = cat.id and cat.id =:c_id", nativeQuery = true)

	FlashSale findByBrand(@Param("c_id")long id);
	
	
	
	
	
	
}
