package com.hanlbs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Subscription;
import com.hanlbs.app.repo.SubscriptionRepsitory;

@Service
public class SubscriptionService {

	@Autowired
	SubscriptionRepsitory repo;

	public Subscription addSub(Subscription sub)throws BlogNotFoundException {

		return repo.save(sub);
	}

	public List<Subscription> subscriptions()throws BlogNotFoundException {

		return repo.findAll();
	}

}
