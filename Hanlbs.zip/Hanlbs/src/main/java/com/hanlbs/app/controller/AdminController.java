package com.hanlbs.app.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.hanlbs.app.config.JwtUtil;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Brands;
import com.hanlbs.app.model.COD;
import com.hanlbs.app.model.Category;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.FlashSale;
import com.hanlbs.app.model.Product;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.User;
import com.hanlbs.app.model.shipping.Country;
import com.hanlbs.app.service.BrandService;
import com.hanlbs.app.service.CODService;
import com.hanlbs.app.service.CategoryService;
import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.FlashSaleService;
import com.hanlbs.app.service.JwtUserDetailsService;
import com.hanlbs.app.service.ProductService;
import com.hanlbs.app.service.UserService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@ApiOperation(value = "Admin conroller ", notes = "you need to login to access this API")
@Api(tags = "CRUD Opration")

public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	@Autowired
	private ProductService productService;
	@Autowired
	private CategoryService catService;
	@Autowired
	private UserService userService;
	@Autowired
	private BrandService brandService;

	@Autowired

	private CustomerService customerService;
	@Autowired

	private FlashSaleService flashSaleService;
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;

	@Autowired
	private JwtUtil jwtUtil;

	@RequestMapping(value = "/addoneProduct", method = RequestMethod.POST)
	@ApiOperation(value = "Add Products with all information")
	public ResponseEntity<?> addOneProduct(@RequestBody Product product) throws BlogNotFoundException {
		logger.info("Add Product Controler ..... ");

		if (product.getName() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product Name is missing.");
		} else if (product.getColor() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("color is missing.");
		} else if (product.getCategory() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("category is missing.");
		} else if (product.getBrand() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Brand is missing.");
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(productService.addOneProduct(product));

		}

	}

	@PutMapping("/updateProducts/{id}")
	@ApiOperation(value = "Update Product by id ")

	public ResponseEntity<String> updateProduct(@PathVariable("id") Long id, @RequestBody Product product)
			throws BlogNotFoundException {
		logger.info("Update Product Controler ..... ");

		if (product.getName() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product Name is missing.");
		} else if (product.getSku() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("bar code is missing.");
		} else {
			productService.updateProduct(id, product);
			return ResponseEntity.status(HttpStatus.OK).body("Product update sucsess.");

		}

	}

	@PostMapping("/addSizeToOldProduct/{ProductId}")
	@ApiOperation(value = "addSizeToOldProduct ")

	public ResponseEntity<ProductMeasurementsSize> addSizeToOldProduct(@PathVariable("ProductId") Long id,
			@RequestBody ProductMeasurementsSize size) throws BlogNotFoundException {
		logger.info("addSizeToOldProduct Controler ..... ");
		return new ResponseEntity<>(productService.addSize(id, size), HttpStatus.OK);
	}

	@PutMapping("/updateProductSize/{sizeid}")
	@ApiOperation(value = "Update ProductSize by Size Id ")

	public ResponseEntity<ProductMeasurementsSize> updateProductSize(@PathVariable("sizeid") Long id,
			@RequestBody ProductMeasurementsSize size) throws BlogNotFoundException {
		logger.info("Update Product Size Controler ..... ");
		return new ResponseEntity<>(productService.updateSize(id, size), HttpStatus.OK);
	}

	@PostMapping("/AddNewProductSize/{ProductId}")
	@ApiOperation(value = "Add ProductSize by Product Id ")

	public ResponseEntity<ProductMeasurementsSize> AddProductSize(@PathVariable("ProductId") Long id,
			@RequestBody ProductMeasurementsSize size) throws BlogNotFoundException {
		logger.info("Add Product Size Controler ..... ");
		return new ResponseEntity<>(productService.addSize(id, size), HttpStatus.OK);
	}

	@PutMapping("/updateCategoryCover/{id}")
	@ApiOperation(value = "Update Category Cover by id ")

	public ResponseEntity<Category> updateCategory(@PathVariable("id") Long id, @RequestBody Category category)
			throws BlogNotFoundException {
		logger.info("Update Category Cover Controler ..... ");
		return new ResponseEntity<>(catService.updateCategoryCover(id, category), HttpStatus.OK);
	}

	@Transactional
	@DeleteMapping("/deleteProduct/{id}")
	@ApiOperation(value = "Delete Product by id ")

	public ResponseEntity<?> deleteProduct(@PathVariable("id") Long id) throws BlogNotFoundException {
		logger.info("delete Product Controler ..... " + id);
		try {
			productService.deleteProduct(id);
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (IOException e) {

			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

		}

	}

	@RequestMapping(value = "/addCategory", method = RequestMethod.POST)
	@ApiOperation(value = "Add Category")

	public ResponseEntity<?> addcategory(@RequestBody Category cat) throws BlogNotFoundException {
		logger.info("Add Category Controler ..... ");
		catService.addCategory(cat);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/updteSubCategory/{id}", method = RequestMethod.PUT)
	@ApiOperation(value = "Edit Sub  Category")

	public ResponseEntity<?> editSubcategory(@PathVariable("id") Long id, @RequestBody Category cat)
			throws BlogNotFoundException {
		logger.info("Add Category Controler ..... ");
		catService.updateCategory(id, cat);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/DeleteSubCategory/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete Sub Category")

	public ResponseEntity<?> deleteSubcategory(@PathVariable("id") Long id) throws BlogNotFoundException {
		logger.info("remove  Category Controler ..... ");
//		catService.addCategory(cat);

		catService.deleteSubCat(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@RequestMapping(value = "/addBrand", method = RequestMethod.POST)
	@ApiOperation(value = "Add Brand")

	public ResponseEntity<Brands> addBrand(@RequestBody Brands brands) throws BlogNotFoundException {
		logger.info("Add Brand Controler ..... ");
		return new ResponseEntity<>(brandService.addBrands(brands), HttpStatus.OK);
	}

	@RequestMapping(value = "/updateBrand", method = RequestMethod.POST)
	@ApiOperation(value = "Edit Brand")

	public ResponseEntity<Brands> EditBrand(@RequestBody Brands brands) throws BlogNotFoundException {
		logger.info("Update Brand Controler ..... ");
		return new ResponseEntity<>(brandService.editBrands(brands), HttpStatus.OK);
	}

//	editBrands

	@Transactional
	@DeleteMapping("/deleteUsers/{id}")

	public ResponseEntity<?> deleteUser(@PathVariable("id") Long id) throws BlogNotFoundException {

		logger.info("remove  User  Controler ..... ");

		userService.deleteUser(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@PostMapping("/create-token")

	public ResponseEntity<?> createToken(@RequestBody Map<String, String> user)
			throws Exception, BlogNotFoundException {

		logger.info("create-token Controler ..... ");
		Map<String, Object> tokenResponse = new HashMap<>();

		final UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(user.get("username"));
		final String token = jwtUtil.generateToken(userDetails);

		tokenResponse.put("token", token);
		return ResponseEntity.ok(tokenResponse);
	}

	@GetMapping("/listCustomers")
	public ResponseEntity<List<Customer>> getCustomers() {
		logger.info("get user Controler ..... ");
		return new ResponseEntity<>(customerService.getCustomer(), HttpStatus.OK);
	}

	@GetMapping("/listCustomersByID/{id}")
	public ResponseEntity<Customer> getCustomersById(@PathVariable("id") Long id) throws BlogNotFoundException {
		logger.info("get user Controler ..... ");
		return new ResponseEntity<>(customerService.getCustomerById(id), HttpStatus.OK);
	}

	@GetMapping("/users")
	public ResponseEntity<List<User>> getUsers() {
		logger.info("get user Controler ..... ");
		return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<User> getUser(@PathVariable("id") Long id) {

		logger.info("get user by id Controler ..... ");
		return new ResponseEntity<>(userService.getUser(id), HttpStatus.OK);
	}

	@PutMapping("/users/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") Long id, @RequestBody Map<String, Object> user)
			throws BlogNotFoundException {
		User newUser = new User((String) user.get("username"), (String) user.get("password"),
				(String) user.get("email"), (String) user.get("name"), (String) user.get("address"),
				(String) user.get("phone"), (boolean) user.get("isAdmin"));
		logger.info("update user by id Controler ..... ");

		return new ResponseEntity<>(userService.updateUser(id, newUser), HttpStatus.OK);
	}

	@RequestMapping(value = "/addFlashSale", method = RequestMethod.POST)
	@ApiOperation(value = "Add Flash Sale ")

	public ResponseEntity<FlashSale> addFlashSale(@RequestBody FlashSale flash) throws BlogNotFoundException {
		logger.info("Add Category Controler ..... ");
		return new ResponseEntity<>(flashSaleService.addFlashSale(flash), HttpStatus.OK);
	}

	@PutMapping("/updateFlashSale/{id}")
	public ResponseEntity<FlashSale> updateFlashSale(@PathVariable("id") Long id, @RequestBody FlashSale flashSale)
			throws BlogNotFoundException {

		logger.info("update user by id Controler ..... ");

		return new ResponseEntity<>(flashSaleService.updateFlashSale(id, flashSale), HttpStatus.OK);
	}

	@GetMapping("/addprodToFlashSale/{prodid}/{flashid}")
	public ResponseEntity<?> addprodToFlashSale(@PathVariable("prodid") Long prodid,
			@PathVariable("flashid") Long flashid) throws BlogNotFoundException {

		logger.info("update flashsale by id Controler ..... ");
		productService.addProductFlashsale(prodid, flashid);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Transactional
	@DeleteMapping("/removeProductfromFlashSale/{id}")
	@ApiOperation(value = "remove product from  FlashSale by id ")
	public ResponseEntity<?> removeprodfromFlashSale(@PathVariable("id") Long prodid) throws BlogNotFoundException {

		logger.info("delete product from flash sale by id Controler ..... ");
		productService.delfromFlash(prodid);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Transactional
	@DeleteMapping("/deleteFlashSale/{id}")
	@ApiOperation(value = "Delete FlashSale by id ")

	public ResponseEntity<?> deleteFlashSale(@PathVariable("id") Long id) throws BlogNotFoundException {
		logger.info("delete Flash Sale Controler ..... ");
		flashSaleService.deleteFlashSale(id);

		return new ResponseEntity<>(HttpStatus.OK);
	}

	@Autowired
	CODService codService;

	@PostMapping("/addCOD")
	@ApiOperation(value = "add COD ")

	public ResponseEntity<Boolean> addCOD(@RequestBody COD cod) throws BlogNotFoundException {

		logger.info("update COD by id Controler ..... ");

		boolean result = codService.addCOD(cod.getFees(), cod.isAcitveCOD());

		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@PutMapping("/updateCOD")
	@ApiOperation(value = "edit COD ")

	public ResponseEntity<Boolean> updateCOD(@RequestBody COD cod) throws BlogNotFoundException {

		logger.info("update COD by id Controler ..... ");

		boolean result = codService.editCOD(cod.getFees(), cod.isAcitveCOD(), cod.getId());

		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping("/allCOD")
	@ApiOperation(value = "All COD ")
	public ResponseEntity<List<COD>> allCOD() throws BlogNotFoundException {
		logger.info("get all COD Controler ..... ");
		return new ResponseEntity<>(codService.AllCOD(), HttpStatus.OK);
	}

	@GetMapping("/getCODByID/{id}")
	@ApiOperation(value = "getCODByID")
	public ResponseEntity<COD> getCODByID(@PathVariable("id") Long id) {

		logger.info("get COD by id Controler ..... ");
		return new ResponseEntity<>(codService.findById(id), HttpStatus.OK);
	}

}
