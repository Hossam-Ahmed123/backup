package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.Payment;

@Repository
public interface PaymentRepostiry extends JpaRepository<Payment, Long> {
	
	
	@Query(value = "SELECT * FROM payment_data u WHERE u.order_key=:orderKey", nativeQuery = true)
	Payment getPaymentbyKey(@Param("orderKey") String  orderKey);

}
