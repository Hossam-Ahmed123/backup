package com.hanlbs.app.model;

public enum OrderStatus {
	REQUESTED,
	INITIATED_RESERVING_STOCK ,
	RESERVED_PROCESSING_PAYMENT, 
	PAYED_PREPARING_FOR_SHIPMENT,
	CANCELLED_OUT_OF_STOCK,
	CANCELLED_PAYMENT_REJECTED,
	Order_submitted_by_customer,
	Order_approved,
	Processing,
	Out_for_delivery,
	Delivered_by_customer,
	rescheduled_by_customer,
	rejected_by_customer
}
