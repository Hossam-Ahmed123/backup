package com.hanlbs.app.dto;

import java.util.List;

import com.hanlbs.app.model.OrderStatus;
import com.hanlbs.app.model.cart.CartItem;

public class OrderDTO {

	private long customerId;
 	private String promoCode;
	private double shippingFees;
	private double subTotal;
	private double cashOnDeliveryFees;
	private double promoValue;
	private double total;
 	
	 

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getCashOnDeliveryFees() {
		return cashOnDeliveryFees;
	}

	public void setCashOnDeliveryFees(double cashOnDeliveryFees) {
		this.cashOnDeliveryFees = cashOnDeliveryFees;
	}

	public double getPromoValue() {
		return promoValue;
	}

	public void setPromoValue(double promoValue) {
		this.promoValue = promoValue;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public double getShippingFees() {
		return shippingFees;
	}

	public void setShippingFees(double shippingFees) {
		this.shippingFees = shippingFees;
	}

 
	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

 
	

}
