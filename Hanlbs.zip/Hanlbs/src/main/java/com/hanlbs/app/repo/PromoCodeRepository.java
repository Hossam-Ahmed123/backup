package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.PromoCode;

@Repository
public interface PromoCodeRepository extends JpaRepository<PromoCode, Long> {

	@Modifying
	@Transactional
	@Query(value = "update  promocode set customer_id = :c_id  WHERE id =:pid ", nativeQuery = true)
	int linkpromoCode(@Param("pid") long promoId, @Param("c_id") long clientId);

	@Modifying
	@Transactional
	@Query(value = "update  promocode set customer_id = null  WHERE id =:pid and customer_id = :c_id ", nativeQuery = true)
	int removeLinkpromoCode(@Param("pid") long promoId, @Param("c_id") long clientId);

	@Query(value = "select discount_value from promocode where customer_id = :c_id  and promo_name=:name ", nativeQuery = true)
	double customerprome(@Param("name") String name, @Param("c_id") long clientId);

}
