package com.hanlbs.app.service;

import java.lang.reflect.Field;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hanlbs.app.dto.OrderData;
import com.hanlbs.app.dto.query.SearchRequest;
import com.hanlbs.app.dto.query.SearchSpecification;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.OrderEvents;
import com.hanlbs.app.model.OrderStatus;
import com.hanlbs.app.model.Orders;
import com.hanlbs.app.model.ProductMeasurementsSize;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.orderdetails.OrderDetails;
import com.hanlbs.app.model.orderdetails.OrderDetailsPK;
import com.hanlbs.app.repo.CartItemRepository;
import com.hanlbs.app.repo.OrderDetailsRepository;
import com.hanlbs.app.repo.OrderRepository;
import com.hanlbs.app.repo.ProductMeasurementsSizeRepository;

@Service
public class OrderService {
	private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

	@Autowired
	private OrderRepository repo;
	@Autowired
	CartItemRepository cartRepo;
	@Autowired
	CustomerService customerServ;
	@Autowired
	private ProductMeasurementsSizeRepository sizeRepo;
	@Autowired
	OrderDetailsRepository orderDetailsRepository;

	public Orders addOrder(Orders orders, String orderKey) throws BlogNotFoundException {
		logger.info("add order service ..... ");
		Orders newOrder = new Orders();

		newOrder.setCustomer(orders.getCustomer());

		newOrder.setStatus(OrderStatus.REQUESTED.toString());
		newOrder.setShippingFees(orders.getShippingFees());
		newOrder.setGrandTotal(orders.getGrandTotal());
		newOrder.setTotal(orders.getTotal());
		newOrder.setDiscount(orders.getDiscount());
		newOrder.setSubTotal(orders.getSubTotal());
		newOrder.setOrderpaid(true);
		newOrder.setPromo(orders.getPromo());
		newOrder.setPromoValue(orders.getPromoValue());
		newOrder.setCashOnDeliveryFees(orders.getCashOnDeliveryFees());
		newOrder.setCOD(orders.isCOD());
		newOrder.setOrderKey(orderKey);
		Orders ora = repo.save(newOrder);

		cartRepo.updateCartOrder(orderKey, orders.getCustomer().getId());

		moveOrderDetails(ora);

		return ora;
	}

	public List<Orders> getOrders() {

		return repo.findAll();
	}

	public List<Orders> getOrdersForCustomer(Long id) {

		Customer customer = customerServ.getCustomerById(id);

		return repo.findAllByCustomer(customer);
	}

	public List<OrderDetails> getOrdersDetials(String orderKey) {

		return orderDetailsRepository.findAllByOrderKey(orderKey);
	}

	public boolean updateOrderStatus(Long id, String value) {

		int result = repo.updateOrderStatus(value, id);
		if (result > 0) {
			return true;
		} else {
			return false;
		}

	}

	public List<OrderEvents> orderTraking(String orderKey) {
		List<OrderEvents> obj = repo.orderTraking(orderKey);

		return obj;

	}

	private String moveOrderDetails(Orders o) throws BlogNotFoundException {

		List<CartItem> cartlist = cartRepo.findAllBycustomerId(o.getCustomer().getId());

		for (CartItem cartItem : cartlist) {

			OrderDetails order = new OrderDetails();

			order.setActive(cartItem.getActive());
			order.setAddedOn(cartItem.getAddedOn());
			order.setColor(cartItem.getColor());
			order.setSize(cartItem.getSize());

			order.setContent(cartItem.getContent());
			OrderDetailsPK pk = new OrderDetailsPK(o.getCustomer(), cartItem.getProduct(), cartItem.getProductSize(),
					o.getOrderKey());
			order.setPk(pk);
			order.setCreatedAt(cartItem.getCreatedAt());
			order.setActive(cartItem.getActive());
			order.setOrdered(true);
			order.setDiscount(cartItem.getDiscount());
			order.setPrice(cartItem.getPrice());
			order.setQuantity(cartItem.getQuantity());
			order.setSize(cartItem.getSize());
			order.setSku(cartItem.getSku());

			orderDetailsRepository.save(order);

			updateStock(cartItem);

		}

		int result = cartRepo.deleteCartOrder(o.getCustomer().getId());
		if (result > 0) {
			return "Done create Order Details";
		} else {
			return "Something Error";
		}

	}

	void updateStock(CartItem cartItem) {

		ProductMeasurementsSize size = sizeRepo.findById(cartItem.getProductSize().getId())
				.orElseThrow(() -> new BlogNotFoundException(
						"Product by id " + cartItem.getProductSize().getId() + " was not found."));

		size.setQuantity(cartItem.getProductSize().getQuantity() - cartItem.getQuantity());
		sizeRepo.save(size);
	}

	public List<Orders> allOrderPage(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Orders> pagedResult = repo.findAll(paging);
		if (pagedResult.hasContent()) {

			return pagedResult.getContent();
		} else {
			return new ArrayList<Orders>();
		}
	}

	private int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public OrderData allOrderPageWithFilter(SearchRequest request) {
		SearchSpecification<Orders> specification = new SearchSpecification<>(request);

		Pageable pageable = SearchSpecification.getPageable(request.getPage(), request.getSize());
//		return repo.findAll(specification, pageable).getContent();

		OrderData orderData = new OrderData();
		orderData.setOrders(repo.findAll(specification, pageable).getContent());
		orderData.setTotalCount(repo.findAll().size());

		return orderData;

	}

}
