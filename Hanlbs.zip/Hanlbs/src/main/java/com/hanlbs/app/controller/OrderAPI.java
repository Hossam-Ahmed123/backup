package com.hanlbs.app.controller;

import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Hex;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.gson.Gson;
import com.hanlbs.app.dto.OrderDTO;
import com.hanlbs.app.dto.OrderData;
import com.hanlbs.app.dto.PaymentDTO;
import com.hanlbs.app.dto.PaymentRequest;
import com.hanlbs.app.dto.query.SearchRequest;
import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.OrderEvents;
import com.hanlbs.app.model.OrderStatus;
import com.hanlbs.app.model.Orders;
import com.hanlbs.app.model.Payment;
import com.hanlbs.app.model.cart.CartItem;
import com.hanlbs.app.model.orderdetails.OrderDetails;
import com.hanlbs.app.repo.PaymentRepostiry;
import com.hanlbs.app.service.CustomerService;
import com.hanlbs.app.service.OrderService;
import com.hanlbs.app.service.payment.PaymentServiceRequest;
//import com.hanlbs.app.service.payment.PaymentServiceStatus;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@RequestMapping("/orderApi")
@Api(tags = "Order API")
public class OrderAPI {
	@Autowired
	PaymentRepostiry payRepo;
	@Value("${payment.returnUrl}")
	private String returnUrl;
	@Value("${payment.cancelUrl}")
	private String cancelUrl;
	@Value("${payment.callbackUrl}")
	private String callbackUrl;
	private static final String privateKey = "OPAYPRV16456316098880.014844069459760467";
	private static final String publicKey = "OPAYPUB16456316098880.16531675797886924";

	private static final String endpoint = "https://sandboxapi.opaycheckout.com";

	private static final String merchantId = "281822022344094";
	private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

	@Autowired
	OrderService ordr;
	@Autowired
	CustomerService customerService;
	@Autowired
	PaymentServiceRequest payRequest;
//	@Autowired
//	PaymentServiceStatus payStauts;

	@RequestMapping(value = "/addCashOnDeliveryOrder", method = RequestMethod.POST)
	@ApiOperation(value = "addCashOn Deliver order ")
	public ResponseEntity<Orders> AddOrder(@RequestBody OrderDTO orders)
			throws URISyntaxException, BlogNotFoundException {

		logger.info("Add Order Controler ..... ");
//		
		String orderKey = java.util.UUID.randomUUID().toString();

		Orders order = new Orders();
		System.out.println(orders.getCustomerId());
		Customer cc = customerService.getCustomerById(orders.getCustomerId());
		System.out.println(cc.getName());

		order.setCustomer(customerService.getCustomerById(orders.getCustomerId()));

		order.setShippingFees(orders.getShippingFees());
		order.setPromo(orders.getPromoCode());
		order.setPromoValue(orders.getPromoValue());
		order.setCashOnDeliveryFees(orders.getCashOnDeliveryFees());
		order.setSubTotal(orders.getSubTotal());
		order.setTotal(orders.getTotal());
		order.setCOD(true);
		Orders done = ordr.addOrder(order, orderKey);
		System.out.println(done.getOrderKey());

		return new ResponseEntity<>(done, HttpStatus.OK);

	}

	@RequestMapping(value = "/addPaymentOrder", method = RequestMethod.POST)
	@ApiOperation(value = "addPaymentOrder ")

	public ResponseEntity<?> paymentApi(@RequestBody PaymentDTO pay) throws Exception, BlogNotFoundException {
		String addr = endpoint + "/api/v1/international/cashier/create";

		Customer cc = customerService.getCustomerById(pay.getCustomerId());
		String orderKey = java.util.UUID.randomUUID().toString();

		URI uri = new URI(addr);
		HttpHeaders headers = new HttpHeaders();
		headers.set("authorization", "Bearer " + publicKey);
		headers.set("Content-Type", "application/json");
		headers.set("MerchantId", merchantId);

		RestTemplate rest = new RestTemplate();

		HttpEntity<TreeMap> request = new HttpEntity<>(
				payRequest.callPaymentAPI(cc, orderKey, pay, returnUrl, callbackUrl, cancelUrl), headers);

		Object obj = rest.postForEntity(uri, request, Object.class);

		Payment payData = new Payment();
		payData.setCustomerId(pay.getCustomerId());
		payData.setOrderKey(orderKey);
		payData.setSubTotal(pay.getSubtotal());
		payData.setPromoCode(pay.getPromoCode());
		payData.setShppingFees(pay.getShppingFees());
		payData.setTotalAmount(pay.getTotalAmount());
		System.out.println(pay.getTotalAmount());
		payRepo.save(payData);

		return ResponseEntity.ok(obj);

	}

	@RequestMapping(value = "/orderStatus/{reference}", method = RequestMethod.POST)
	@ApiOperation(value = "checkPayment Status")

	public ResponseEntity<?> paymentApiStatus1(@PathVariable("reference") String orderKey)
			throws Exception, BlogNotFoundException {
		String addr = endpoint + "/api/v1/international/cashier/status";
		Gson gson = new Gson();
		TreeMap order = new TreeMap<>();
		order.put("reference", orderKey);
		order.put("country", "EG");
		String requestBody = gson.toJson(order);
		String oPaySignature = hmacSHA512(requestBody, privateKey);

		URI uri = new URI(addr);
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + oPaySignature);

		headers.set("Content-Type", "application/json");
		headers.set("MerchantId", merchantId);
		RestTemplate rest = new RestTemplate();

		HttpEntity<TreeMap> request = new HttpEntity<>(order, headers);

		return ResponseEntity.ok(rest.postForEntity(uri, request, Object.class));

	}

	@RequestMapping(value = "/payStatus/{reference}", method = RequestMethod.POST)
	@ApiOperation(value = "checkPayment Status")

	public ResponseEntity<?> paymentApiStatus(@PathVariable("reference") String orderKey)
			throws Exception, BlogNotFoundException {
		String addr = endpoint + "/api/v1/international/cashier/status";
		Gson gson = new Gson();
		TreeMap order = new TreeMap<>();
		order.put("reference", orderKey);
		order.put("country", "EG");
		String requestBody = gson.toJson(order);
		String oPaySignature = hmacSHA512(requestBody, privateKey);

		URI uri = new URI(addr);
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + oPaySignature);

		headers.set("Content-Type", "application/json");
		headers.set("MerchantId", merchantId);
		RestTemplate rest = new RestTemplate();

		HttpEntity<TreeMap> request = new HttpEntity<>(order, headers);

		return ResponseEntity.ok(rest.postForEntity(uri, request, Object.class));

	}

	@RequestMapping(value = "/ConfirmOrderAfterPay/{orderKey}", method = RequestMethod.POST)
	@ApiOperation(value = "ConfirmOrderAfterPay")
	public ResponseEntity<Orders> insureOrder(@PathVariable("orderKey") String orderKey)
			throws URISyntaxException, BlogNotFoundException {

		logger.info("Add Order Controler ..... ");
//		

		Payment afterpay = payRepo.getPaymentbyKey(orderKey);

		Orders order = new Orders();
		Customer cc = customerService.getCustomerById(afterpay.getCustomerId());
		System.out.println(cc.getName());

		order.setCustomer(customerService.getCustomerById(afterpay.getCustomerId()));

		order.setShippingFees(afterpay.getShppingFees());
		order.setPromoValue(afterpay.getPromoCode());
		order.setSubTotal(afterpay.getSubTotal());
		order.setTotal(afterpay.getTotalAmount());
		order.setCOD(false);
		Orders done = ordr.addOrder(order, orderKey);
		System.out.println(done.getOrderKey());

		return new ResponseEntity<>(done, HttpStatus.OK);

	}

	@GetMapping("/Orders")
	@ApiOperation(value = "Get all Orders")
	public ResponseEntity<List<Orders>> getAllOrder() {
		logger.info("get all Orders     Controler ..... ");

		return new ResponseEntity<>(ordr.getOrders(), HttpStatus.OK);
	}

	@GetMapping("/customer/{id}/Orders")
	@ApiOperation(value = "Get Orders for customer")
	public ResponseEntity<List<Orders>> getCustomerOrders(@PathVariable("id") Long id) {
		logger.info("get Customer Order by userId Controler ..... ");

		return new ResponseEntity<>(ordr.getOrdersForCustomer(id), HttpStatus.OK);
	}

	@GetMapping("/ordersDetails/{orderkey}")
	@ApiOperation(value = "Get orders Details")
	public ResponseEntity<List<OrderDetails>> getCustomerOrderDetails(@PathVariable("orderkey") String key) {
		logger.info("get Customer Order details by  orderKey Controler ..... ");

		return new ResponseEntity<>(ordr.getOrdersDetials(key), HttpStatus.OK);
	}

	@RequestMapping(value = "/updateOrderStatus/{orderid}/{status}", method = RequestMethod.PUT)
	@ApiOperation(value = "Update Order Status")
	public ResponseEntity<Boolean> updateOrderStatus(@PathVariable("orderid") Long id,
			@PathVariable("status") String value) throws BlogNotFoundException {
		logger.info("update Order by userId Controler ..... ");

		return new ResponseEntity<>(ordr.updateOrderStatus(id, value), HttpStatus.OK);
	}

	@GetMapping("/OrdersStatusLookup")
	@ApiOperation(value = "Get Orders Status")
	public ResponseEntity<?> getOrderStatus() {
		logger.info("get Status Order by  Controler ..... ");

		OrderStatus[] status = OrderStatus.values();

		return new ResponseEntity<>(status, HttpStatus.OK);
	}

	@JsonIgnore
	public static String hmacSHA512(final String data, final String secureKey) throws Exception, BlogNotFoundException {
		byte[] bytesKey = secureKey.getBytes();
		final SecretKeySpec secretKey = new SecretKeySpec(bytesKey, "HmacSHA512");
		Mac mac = Mac.getInstance("HmacSHA512");
		mac.init(secretKey);
		final byte[] macData = mac.doFinal(data.getBytes());
		byte[] hex = new Hex().encode(macData);
		return new String(hex, StandardCharsets.UTF_8);
	}

	@GetMapping("/orderTraking/{orderKey}")
	@ApiOperation(value = "Get orderTraking")
	public ResponseEntity<List<OrderEvents>> orderTraking(@PathVariable("orderKey") String orderKey) {
		logger.info("get Status Order by  Controler ..... ");

		return new ResponseEntity<>(ordr.orderTraking(orderKey), HttpStatus.OK);
	}

	@GetMapping("/ordersPagination/{pageNo}/{pageSize}/{sortBy}")
	@ApiOperation(value = "Get orders Pagination")
	public ResponseEntity<List<Orders>> ordersPagination(
			@PathVariable("pageNo") @RequestParam(defaultValue = "0") Integer pageNo,
			@PathVariable("pageSize") @RequestParam(defaultValue = "10") Integer pageSize,
			@PathVariable("sortBy") @RequestParam(defaultValue = "id") String sortBy) {
		List<Orders> list = ordr.allOrderPage(pageNo, pageSize, sortBy);

		return new ResponseEntity<List<Orders>>(list, new HttpHeaders(), HttpStatus.OK);
	}

	@PostMapping(value = "/ordersPaginationAndFiltter")

	@ApiOperation(value = "Get orders Pagination and Filtter")
	public ResponseEntity<OrderData> search(@RequestBody SearchRequest request) {
		OrderData order = ordr.allOrderPageWithFilter(request);

		return new ResponseEntity<>(order, new HttpHeaders(), HttpStatus.OK);
	}

}
