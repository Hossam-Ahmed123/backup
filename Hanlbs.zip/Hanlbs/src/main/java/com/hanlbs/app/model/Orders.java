package com.hanlbs.app.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.hanlbs.app.model.cart.CartItem;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "orders")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Orders implements Serializable {

	private static final long serialVersionUID = -6571020025726257848L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private boolean isCOD;
	private String orderKey;

	@ManyToOne

	private Customer customer;

	public double getCashOnDeliveryFees() {
		return cashOnDeliveryFees;
	}

	public void setCashOnDeliveryFees(double cashOnDeliveryFees) {
		this.cashOnDeliveryFees = cashOnDeliveryFees;
	}

	public double getPromoValue() {
		return promoValue;
	}

	public void setPromoValue(double promoValue) {
		this.promoValue = promoValue;
	}

	private String status;

	private double subTotal;
	private double cashOnDeliveryFees;
	private double promoValue;
	private double total;
	private String promo;
	private double discount;
	private double grandTotal;
	private double shippingFees;

	private boolean orderpaid;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date createdAt = new Date();
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	private Date updatedAt = new Date();

	private String content;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@JsonIgnore
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getSubTotal() {
		return Math.round(subTotal);
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getTotal() {
		return Math.round(total);
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getPromo() {
		return promo;
	}

	public void setPromo(String promo) {
		this.promo = promo;
	}

	public double getDiscount() {
		return Math.round(discount);
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getGrandTotal() {
		return Math.round(grandTotal);
	}

	public void setGrandTotal(double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public double getShippingFees() {
		return Math.round(shippingFees);
	}

	public void setShippingFees(double shippingFees) {
		this.shippingFees = shippingFees;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getOrderKey() {
		return orderKey;
	}

	public void setOrderKey(String orderKey) {
		this.orderKey = orderKey;
	}

	public boolean isOrderpaid() {
		return orderpaid;
	}

	public void setOrderpaid(boolean orderpaid) {
		this.orderpaid = orderpaid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isCOD() {
		return isCOD;
	}

	public void setCOD(boolean isCOD) {
		this.isCOD = isCOD;
	}

}
