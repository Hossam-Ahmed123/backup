package com.hanlbs.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cod")
public class COD {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private double fees;
	private boolean acitveCOD;

	public boolean isAcitveCOD() {
		return acitveCOD;
	}

	public void setAcitveCOD(boolean acitveCOD) {
		this.acitveCOD = acitveCOD;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getFees() {
		return Math.round(fees);
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

}
