package com.hanlbs.app.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.User;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.repo.UserRepository;

import java.util.ArrayList;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(JwtUserDetailsService.class);

	@Autowired
	private UserRepository repo;
	@Autowired
	private CustomerRepository customerRepo;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) {
		User user = repo.findByUsername(username);
		logger.info("loadUser By Username Service ..... " + username);
		Object obj = null;
		if (user == null) {
			Customer customer = customerRepo.findByEmail(username);
			obj = new org.springframework.security.core.userdetails.User(customer.getEmail(), customer.getPassword(),
					new ArrayList<>());

		} else {

			obj = new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
					new ArrayList<>());

		}

		return (UserDetails) obj;

	}

	public User save(User user) {
		logger.info("save user By User object Service ..... " + user.getName());

		User newUser = new User(user.getUsername(), bcryptEncoder.encode(user.getPassword()), user.getEmail(),
				user.getName(), user.getAddress(), user.getPhone(), user.isAdmin());

		return repo.save(newUser);
	}

	public User loadUsercontrolByUsername(String username) throws UsernameNotFoundException {
		User user = repo.findByUsernameandtype(username);
		logger.info("load User control By Username Service ..... " + username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found with the username of: " + username);
		}

		return user;
	}

}
