package com.hanlbs.app.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payment_data")

public class Payment implements Serializable {

	public double getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}
	private static final long serialVersionUID = -6571020025726257848L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String orderKey;
	private double subTotal;
	private double totalAmount;
	private long customerId;
	private double shppingFees;
	private double promoCode;
	private boolean isCOD;
	
	public boolean isCOD() {
		return isCOD;
	}
	public void setCOD(boolean isCOD) {
		this.isCOD = isCOD;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getOrderKey() {
		return orderKey;
	}
	public void setOrderKey(String orderKey) {
		this.orderKey = orderKey;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public double getShppingFees() {
		return shppingFees;
	}
	public void setShppingFees(double shppingFees) {
		this.shppingFees = shppingFees;
	}
	public double getPromoCode() {
		return promoCode;
	}
	public void setPromoCode(double promoCode) {
		this.promoCode = promoCode;
	}
	 
	
	
	
	
	

}
