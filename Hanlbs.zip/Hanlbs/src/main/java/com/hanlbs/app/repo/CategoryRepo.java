package com.hanlbs.app.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hanlbs.app.model.Category;

@Repository
public interface CategoryRepo extends JpaRepository<Category, Long> {

	@Query(value = "SELECT * FROM category u WHERE u.parencatid is null", nativeQuery = true)
	List<Category> findAllCategoriesbyparent();

	@Query(value = "SELECT u.parencatid FROM category u WHERE u.parencatid is not null and category_id =:c_id", nativeQuery = true)
	int findAllparentcategorybysub(@Param("c_id") long id);

	@Modifying
	@Transactional
	@Query(value = "insert into  category  (name,parencatid,cover_photo) values (:name , :c_id , :image)", nativeQuery = true)
	void insertSubcate(@Param("name") String name, @Param("c_id") long id, @Param("image") String coverImage);

	@Modifying
	@Transactional
	@Query(value = "update  category  set name = :name where category_id =:c_id", nativeQuery = true)
	void updateSubcate(@Param("name") String name, @Param("c_id") long id);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM  category  where category_id =:c_id", nativeQuery = true)
	void deleteSubcate(@Param("c_id") long id);

}
