package com.hanlbs.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hanlbs.app.model.COD;

@Repository
public interface CODRepsitory extends JpaRepository<COD, Long>{

}
