package com.hanlbs.app.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hanlbs.app.config.JwtUtil;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.service.JwtCustomerDetailsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@CrossOrigin
@Api(tags = "Customer Registration")

public class JwtAuthenticationControllerForCustomer {
	private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationControllerForCustomer.class);

	@Autowired
	private CustomerRepository customerRepo;

	@Autowired
	private JwtCustomerDetailsService JwtcustomerDetailsService;
	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	@RequestMapping(value = "/currentCustomer", method = RequestMethod.GET)
	public ResponseEntity<Customer> getCurrentCustomer(HttpServletRequest request) {
		logger.info("current Customer    ");

		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		logger.info("current Customer ");
		Customer customer = customerRepo.findByEmail(((UserDetails) principal).getUsername());
		return ResponseEntity.ok(customer);
	}

	@RequestMapping(value = "/CustomerLogin", method = RequestMethod.POST)
	@ApiOperation(value = "Login for customer")
	public ResponseEntity<?> authenticateUser(@RequestBody Map<String, String> customer) {
		logger.info("CustomerLogin ..... ");

		authenticate(customer.get("email"), customer.get("password"));
		logger.info("CustomerLogin ..... ");

		Map<String, Object> tokenResponse = new HashMap<>();
		final UserDetails userDetails = JwtcustomerDetailsService.loadUserByUsername(customer.get("email"));
		final String token = jwtUtil.generateToken(userDetails);

		tokenResponse.put("token", token);
		return ResponseEntity.ok(tokenResponse);
	}

	private void authenticate(String username, String password) {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			logger.error("User disabled", e);
		} catch (BadCredentialsException e) {
			logger.error("Invalid credentials", e);
		}
	}

	@RequestMapping(value = "/customerRegister", method = RequestMethod.POST)
	@ApiOperation(value = "Register for user")
	public ResponseEntity<?> customerRegister(@RequestBody Map<String, Object> user) {
		Customer savedCustomer = new Customer();
		Customer newCustomer = new Customer((String) user.get("password"),
				(String) user.get("email"), (String) user.get("name"), 
				(String) user.get("phone"));

	 

		if (newCustomer.getEmail() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is missing.");
		}

		if (newCustomer.getPassword() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password is missing.");
		} else if (newCustomer.getPassword().length() < 8) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password length must be 8+.");
		}

		if (newCustomer.getName() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Name is missing.");
		}

		 

		if (newCustomer.getPhone() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Phone is missing.");
		}

		try {
			savedCustomer = JwtcustomerDetailsService.save(newCustomer);
		} catch (DataIntegrityViolationException e) {
			if (e.getRootCause().getMessage().contains(newCustomer.getEmail())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("email is not available.");
			}

			if (e.getRootCause().getMessage().contains(newCustomer.getEmail())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is not available.");
			}
		}

		Map<String, Object> tokenResponse = new HashMap<>();

		final UserDetails userDetails = JwtcustomerDetailsService.loadUserByUsername(savedCustomer.getEmail());
		final String token = jwtUtil.generateToken(userDetails);

		tokenResponse.put("token", token);
		return ResponseEntity.status(HttpStatus.CREATED).body(tokenResponse);
	}

}
