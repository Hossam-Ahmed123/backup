package com.hanlbs.app.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hanlbs.app.exceptions.BlogNotFoundException;

@ControllerAdvice

public class GlobalExceptionHandler {
	@ExceptionHandler(value = BlogNotFoundException.class)
	public ResponseEntity blogNotFoundException(BlogNotFoundException blogNotFoundException) {
		return new ResponseEntity("Error", HttpStatus.NOT_FOUND);
	}
}
