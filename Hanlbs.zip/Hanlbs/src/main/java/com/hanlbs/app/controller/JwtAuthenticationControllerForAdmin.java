package com.hanlbs.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import com.hanlbs.app.config.JwtUtil;
import com.hanlbs.app.model.Customer;
import com.hanlbs.app.model.User;
import com.hanlbs.app.repo.CustomerRepository;
import com.hanlbs.app.repo.UserRepository;
import com.hanlbs.app.service.JwtCustomerDetailsService;
import com.hanlbs.app.service.JwtUserDetailsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RestController

@CrossOrigin
@Api(tags = "Controll panal Registration")

public class JwtAuthenticationControllerForAdmin {
	private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationControllerForAdmin.class);

	@Autowired
	private UserRepository repo;
	@Autowired
	private JwtUserDetailsService jwtUserDetailsService;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private AuthenticationManager authenticationManager;

	
	@RequestMapping(value = "/currentUser", method = RequestMethod.GET)
	public ResponseEntity<User> getCurrentUser(HttpServletRequest request) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = repo.findByUsername(((UserDetails) principal).getUsername());
		return ResponseEntity.ok(user);
	}

	
	@RequestMapping(value = "/userRegister", method = RequestMethod.POST)
	@ApiOperation(value = "Register for user")

	public ResponseEntity<?> registerUser(@RequestBody Map<String, Object> user) {
		User savedUser = new User();
		boolean bool = Boolean.parseBoolean((String) user.get("isAdmin"));
		User newUser = new User((String) user.get("username"), (String) user.get("password"),
				(String) user.get("email"), (String) user.get("name"), (String) user.get("address"),
				(String) user.get("phone"), bool);

		if (newUser.getUsername() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username is missing.");
		}

		if (newUser.getEmail() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is missing.");
		}

		if (newUser.getPassword() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password is missing.");
		} else if (newUser.getPassword().length() < 8) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Password length must be 8+.");
		}

		if (newUser.getName() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Name is missing.");
		}

		if (newUser.getAddress() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Address is missing.");
		}

		if (newUser.getPhone() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Phone is missing.");
		}

		try {
			savedUser = jwtUserDetailsService.save(newUser);
		} catch (DataIntegrityViolationException e) {
			if (e.getRootCause().getMessage().contains(newUser.getUsername())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username is not available.");
			}

			if (e.getRootCause().getMessage().contains(newUser.getEmail())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email is not available.");
			}
		}

		Map<String, Object> tokenResponse = new HashMap<>();

		final UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(savedUser.getUsername());
		final String token = jwtUtil.generateToken(userDetails);

		tokenResponse.put("token", token);
		return ResponseEntity.status(HttpStatus.CREATED).body(tokenResponse);
	}

	private void authenticate(String username, String password) {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			logger.error("User disabled", e);
		} catch (BadCredentialsException e) {
			logger.error("Invalid credentials", e);
		}
	}

	

	@RequestMapping(value = "/controllogin", method = RequestMethod.POST)
	@ApiOperation(value = "Login for Admin")

	public ResponseEntity<?> controlgin(@RequestBody Map<String, String> user) {
		authenticate(user.get("username"), user.get("password"));

		Map<String, Object> tokenResponse = new HashMap<>();
		final UserDetails userDetails = jwtUserDetailsService.loadUserByUsername(user.get("username"));
		final User userType = jwtUserDetailsService.loadUsercontrolByUsername(user.get("username"));

		final String token = jwtUtil.generateToken(userDetails);
		String type;
		if (userType.isAdmin() == true) {
			type = "admin";
		} else {
			type = "user";

		}
		tokenResponse.put("token", token);
		tokenResponse.put("type", type);
		return ResponseEntity.ok(tokenResponse);
	}

}
