package com.hanlbs.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hanlbs.app.exceptions.BlogNotFoundException;
import com.hanlbs.app.model.PromoCode;
import com.hanlbs.app.repo.PromoCodeRepository;

@Service
public class PromoCodeService {

	@Autowired
	private PromoCodeRepository repo;

	public PromoCode addPromo(PromoCode pCode) {

		return repo.save(pCode);
	}

	public PromoCode getPromoById(Long id) {

		return repo.findById(id)
				.orElseThrow(() -> new BlogNotFoundException("Product by id " + id + " was not found."));
	}

	public double getPromoByIdAndPromoNAme(Long id, String pName) throws BlogNotFoundException {

		return repo.customerprome(pName, id);
	}

	public List<PromoCode> allPromocodes() {

		return repo.findAll();

	}

	public PromoCode updatePromro(PromoCode pCode, Long id) throws BlogNotFoundException {

		PromoCode p = getPromoById(id);
//		p.setCategory(pCode.getCategory());
		p.setDiscountType(pCode.getDiscountType());
		p.setDiscountValue(pCode.getDiscountValue());
		p.setNumUsed(pCode.getNumUsed());
		p.setPromoName(pCode.getPromoName());
		p.setPromoType(pCode.getPromoType());
		return repo.save(p);

	}
//	public PromoCode linkClientPromoCode(PromoCode pCode, Long id) {
//
//		PromoCode p = getPromoById(id);
////		p.setCategory(pCode.getCategory());
//		p.setDiscountType(pCode.getDiscountType());
//		p.setDiscountValue(pCode.getDiscountValue());
//		p.setNumUsed(pCode.getNumUsed());
//		p.setPromoName(pCode.getPromoName());
//		p.setPromoType(pCode.getPromoType());
//		return repo.save(p);
//
//	}

	public void deletePromocode(long id) throws BlogNotFoundException {

		PromoCode p = getPromoById(id);
		repo.delete(p);

	}

	public String linkPromocode(Long promoId, Long clientId) {

		int result = repo.linkpromoCode(promoId, clientId);
		if (result > 0) {
			return "done Link";
		} else {
			return "Error";
		}

	}

	public String removelinkPromocode(Long promoId, Long clientId) throws BlogNotFoundException {

		int result = repo.removeLinkpromoCode(promoId, clientId);
		if (result > 0) {
			return "done Remove Link";
		} else {
			return "Error";
		}

	}

}
